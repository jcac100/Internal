# 23_ME_01

| FY | Audience | Scenario | Description | Version |
| --- | --- | --- | --- | --- |
| 23 | Mission Element | 01 | Sliver | v3.0.0 |


**Instructions:**
```
# Pull Repo
git clone https://gitlab.pwn3d.lol/mccann/23_me_01

# Open '23_me_01' directory in Obsidian
Obsidian --> Open Folder as Vault --> './23_me_01'
```


# MECT Scenario: Sliver

## Phase 1: Initial Access
**Step 0: Pre-Emulation Plan Configuration**
- Remove excess & malicious looking administrator accounts.
- Setup attacker networking.

**Step 1: Initial Access into the DMZ via an Authenticated File Upload**
- The uploaded file is a malicious '.phar'.
- This '.phar' upload contains a TinyShell payload, giving us a webshell within the DMZ as user 'www-root'.

**Step 2: Local Privilege Escalation via SUID bit set on 'systemctl'**
- Exploitation of the SUID bit set on '/bin/systemctl' combined with a Sliver beacon.
- This returns an elevated beacon as 'root' on the WEB DMZ.

---

## Phase 2: Lateral Movement into the Domain
**Step 3: Local SQL DB Credentials Leaked via Configuration File**
- Hardcoded SQL credentials found in a web configuration file.
- These crededentials allow us to access a locally hosted MySQL database

**Step 4: Lateral Movement into Domain via Linked Internal MS-SQL DB**
- The local MySQL DB reveals it is linked to an MS-SQL DB within the domain.
- DB also reveals credentials to the linked MS-SQL DB.
- Through a proxy setup on the Web DMZ, connect to the MS-SQL DB using 'impacket-mssqlclient'.
- The user has valid permissions to enable 'xp_cmdshell', allowing RCE.

**Step 5: Privilege Escalation on Internal MS-SQL DB**
- Enumerating the host using 'xp_cmdshell' reveals the current user has 'SeImpersonatePrivilege'.
- Download 'EfsPotato.exe' and a Sliver beacon to the victim.
- 'EfsPotato.exe' exploits 'SeImpersonatePrivilege', running the beacon as NT AUTHORITY/SYSTEM.

---

## Phase 3: Privilege Escalation within the Domain 
**Step 6: Logged on Domain Administrator NTLM Hash Dumped from MS-SQL DB**
- A Domain Administrator is currently logged onto the SQL server.
- LSASS process memory is dumped and cracked offline to acquire the user's NTLM hash.

**Step 7: Lateral Movement through Domain via Domain Administrator TGT**
- Utilizing Rubeus on the SQL server, a Ticket-Granting-Ticket (TGT) is created using the NLTM hash.
- This ticket is utilized to laterally move throughout the network as the DA using 'psexec'.
- All 'psexec' sessions are ran as NT AUTHORITY/SYSTEM. 

**Step 8: Establish Persistence on Hosts throughout the Domain**
- Using elevated sessions, two forms of persistence are set on different hosts.
- First form is an obvious HKLM Run registry key.
- Second form is an obfuscated Scheduled Task.

---

## Phase 4: Impact
**Step 9: Deploy Ransomware throughout the Domain**
- Method 1: Compile TrashPanda ransomware on attacker
- Method 2: Use modified 'GonnaCope.bat' ransomware.
- Deploy via GPO or scheduled task.