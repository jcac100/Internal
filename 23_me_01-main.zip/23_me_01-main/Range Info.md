### Table of Contents
---

- [ ] [[Range Info#Range Overview|Range Overview]]
- [ ] [[Range Info#User Credentials|User Credentials]]

### Range Overview
---

The PCTE range consists of two mirrored networks -- MDA and PAO.  This plan can be conducted on either side, the MECT scenario will likely determine which network to use.
- For scenarios involving 1CYBN, the MDA network will almost always be used.

![[Pasted image 20230620153000.png]]

**Attacker Subnet:**
```
# 30.0.0.0/24
red-ops-kali-1     =  30.0.0.10
red-ops-kali-2     =  30.0.0.11
```

Throughout the plan, you can use multiple different compromised domains so that our attacks don't point back to the 30.0.0.0/24 attacker space.  You can choose however many domains you want and use them throughout the emulation plan.  The range should point to an external DNS server, 1.1.1.1, with records for the following domains:

**List of Currently Available Compromised Domains:**
```
# 152.42.85.0/24
video.memezilla.com.cn  =  152.42.85.67
www.google.com.cn       =  152.42.85.236
```

```
# 63.72.115.0/24
www.google.com.co  =  63.72.155.49
www.google.com.pa  =  63.72.115.8
```

```
# 188.64.30.0/24
www.google.com.ve  =  188.64.30.214
youztubi.com.pa    =  188.64.30.95
```

**Development Note:**
To add extra DNS records to the 1.1.1.1 DNS server, utilize the PowerDNS admin panel.
```
# PowerDNS
URL      : http://10.10.1.101:30000/login
Username : admin
Password : admin
```

[[Range Info#Table of Contents|Return to Table-of-Contents]]
### User Credentials
---

- **Administrators**

```
# Domain Admin Credentials
princess.peach   -->  flowerpower12!@
dominic.toretto  -->  need4speed!
travis.bickle    -->  Taxidriver12!@
kevin.beacon     -->  qwer1234QWER!@#$

# Local Admin Credentials
Administrator    -->  Simspace1!Simspace1!
```

-  **MDA Users**

```
# MDA-CMD User Credentials
mda-cmd0.mda.mil : bridgette.hutchinson  -->  w#9$Ey#a9D4U
mda-cmd1.mda.mil : tommie.schultz        -->  w5B@5S@7@v6@

# MDA-S1 User Credentials
mda-s1-0.mda.mil : vera.wade   -->  M@S2$3F$s7$Z
mda-s1-1.mda.mil : bryon.ball  -->  qBy6@3gL+wFn

# MDA-S2 User Credentials
mda-s2-0.mda.mil : jessica.benton  -->  BP+P3+7$t4U3
mda-s2-1.mda.mil : jan.pacheco     -->  BT5e$N$Tp3pI

# MDA-S3 User Credentials
mda-s3-0.mda.mil : louise.mack       -->  T4S8+x6zN7b+
mda-s3-1.mda.mil : fernando.buckley  -->  PE#6ZdRz+P7+

# MDA-S6 User Credentials
mda-s6-0.mda.mil : jeri.wu           -->  B+N5K#6YzJ#f
mda-s6-1.mda.mil : houston.clements  -->  AM$M+u2h@o4W

# MDA VPN User Credentials
mda-vpn-user.mda.mil : cruz.harrison  -->  j+U8H@W@L5$a
```


- **PAO Users**

```
# PAO-CMD User Credentials
pao-cmd0.pao.mil : jodie.villa       -->  BL5Y@q4@We@8
pao-cmd1.pao.mil : guadalupe.chaney  -->  y@8+9#f4#kK3

# PAO-S1 User Credentials
pao-s1-0.pao.mil : denise.arias   -->  m@3b+9#q$v#U
pao-s1-1.pao.mil : jeffry.powell  -->  gW8A9Lp@Z7p$

# PAO-S2 User Credentials
pao-s2-0.pao.mil : rachelle.conley  -->  T#n#3#N9#h+K
pao-s2-1.pao.mil : randy.benitez    -->  i#x+Ju5D2B#o

# PAO-S3 User Credentials
pao-s3-0.pao.mil : yvette.white  -->  d+gH@X2#2n9S
pao-s3-1.pao.mil : zander.kirk   -->  x#i+aE5+7M6r

# PAO-S6 User Credentials
pao-s6-0.pao.mil     : terry.todd        -->  H3pEa+R2v$Q5
pao-s6-1.pao.mil     : celeste.garrison  -->  bP+Gn8Yo8@5#

# PAO VPN User Credentials
pao-vpn-user.pao.mil : gerald.mcneil     -->  n+6$nJ@F#2L6
```

[[Range Info#Table of Contents|Return to Table-of-Contents]]
