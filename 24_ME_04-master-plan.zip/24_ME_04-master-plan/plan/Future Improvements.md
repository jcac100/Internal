
Improvements list:
3) Address manual psexec triggering critical "File creation request in Remote System32 Directory"
4) Rewrite militarycac trojan to not include "-nop" string- triggers critical alert
5) Executing SweetPotato causes 30+ critical WMIC alerts per execution. Also, utilizing the logonscript again to "avoid creating new artifacts" may be worse than the alternatives
	- This deserves a section rewrite-- maybe one execution of SweetPotato, inject into a domain user process, use their permissions to abuse something like DACL perms? 3x sweet potato sucks.
	- Current path is get system 3x on S1-0, S1-1, CMD1. Then, use CMD1 to get HelpDesk user, and S1-0 and S1-1 are used for execution/pivoting traffic.
	- Slightly better version for now, only persist as system on S1-1 and CMD1, and ignore S1-0. Use S1-1 for both execution and pivoting
1) Uploading/moving executables via SMB triggers an alert, consider encoding/obfuscating the file
2) Incorporate silencing or unhooking sysmon, and/or degrading logstash on 5044. 
3) Make removing excess domain admins an actual setup step and not just a note. also verify that houston.clements is a DA
4) instead of `cacls`, use powerview earlier to see a difference between NETLOGON and `SYSVOL\mda.mil\scripts`
5) Change `houston.clements` password in setup so cracking is more feasible
6) Use more C2 domains, ideally multiple per beacon. Failover C2 can begin to be used near the end if we still want to use it (see C2 rebuild)
7) Incorporate more APT27 TTPs, like from [this link](https://symantec-enterprise-blogs.security.com/blogs/threat-intelligence/budworm-tool-update-telecoms-govt)
	1) Replace ADExplorer with AdFind
	2) Maybe replace ProcDump with SecretsDump (impacket)
8) Use more log-clearing and covering of tracks, if permissible. An easy example is mass-clearing the WinEvent logs during Phase 4, and maybe wiping logs on the webserver. A lot of artifacts are left behind in the current state of the plan, which is both a good and bad thing
9) At the end of "Pass-the-Hash, Laterally Move to S6", consider some other method that's quieter than psexec. Set up dll hijack over SMB or "manual psexec" //psexec might actually not be so bad



DONE- TEST THIS //Un-signature all of the jQuery profile and Phase 4 variant
DONE- PowerShell user agent can be made custom with `-UserAgent`: will probably need to use this again with logonscript