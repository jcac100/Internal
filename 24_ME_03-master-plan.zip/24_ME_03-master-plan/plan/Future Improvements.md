# Future Improvements

# Photos for Proof.rar get emailed as corrupt
# Lojax as Persistence

# Adding persistent Authorized Key file on Vyatta

