
## Old
---
Separate users into OUs relative to their positions (As seen in the Range Info tables) so that plans that play off of Active Directory can be configured more easily in the future. 

## Less Old
---
> [!danger] McCann Bullshit (pre-inserted notes)
> First and foremost:
> - Domain Administrator needs to be used instead of `zander.kirk`
> - Add a second MDA section to the plan.
> - Add a PAO VPN.
> - Add a space to the end of the PowerShell macro for successful command execution.
> - Add explanations for what the fuck is going on.
> 


## 01FEB2024
---

> [!danger] McCann Bullshit
> - Payloads / domains have been standardized.
> - Independent Kali 1 and 2 configurations.
> - Fixed GPO typos and added troubleshooting.
> - VPN configuration / usage has been ironed out on both sides of the domain.
> - MDA and PAO are both working plans.