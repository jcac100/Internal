
### TL;DR

```
# Initial Access
- RDP into the S1 subnet using VPN credentials acquired from a disgruntled employee.
- Generate a macro infested Microsoft Excel document that allows for local code execution.

# Discovery & Lateral Movement
- Use adpeas.ps1 for domain enumeration, revealing an ASREP rostable account.
- Use asreproast.ps1 to acquire the NTLM hash of the roastable user.
- Crack the user's password offline using john.
- Use runas.ps1 with the roasted account's credentials to add our current user to the S6_Users group.
- RDP into the S6 subnet using the S1 user credentials.

# Privilege Escalation
- Use Task Manager to dump the lsass.exe process memory.
- Extract lsass dump via RDP or PowerShell.
- Dump local Adminstrator's password offline using Pypykatz.
- Use local administator to execute remote WMIC commands on SHRPT server.
- Remotely extract LSASS from SHRPT via comsvcs.dll.
- Dump creds of a domain adminstrator logged into SHRPT.

# Impact / Exfiltration
- Using the domain administrator, use a remote scheduled tasks for command execution on the DC.
- Execute fodhelper UAC bypass to create a local backup of current Active Directory instance.
- Exfiltrate the generated AD backup via PowerShell.
```

## MECT Scenario: Volt Typhoon
---
### Phase 1: Initial Access

**Step 0: Pre-Emulation Plan Configuration**

- Configure attacker networking, vulnerabilities, and payloads.

**Step 1: RDP into the Domain**

- RDP into the S1 subnet using VPN credentials acquired from a disgruntled employee.

**Step 2: Local Code Execution**

- Generate a macro infested Microsoft Excel document that allows for local code execution through wscript.

- Use code execution to find an unblocked PowerShell executable.

- Modify macro to execute code through new PowerShell executable.

---

### Phase 2: Discovery & Lateral Movement

**Step 3: Active Directory Enumeration**

- Use `adpeas.ps1` for domain enumeration, revealing an ASREP rostable account.

**Step 4: Acquire User Credentials**

- Use `asreproast.ps1` to acquire the NTLM hash of the ASREP roastable user.
- Crack the user's password offline using john.

**Step 5: Modify User Permissions**

- The ASREP roasted account has DACL permissions to modify the S6_Users group.
- Use `runas.ps1` with the ASREP roasted account's credentials to add our current compromised S1 user to the S6_Users group.  


**Step 6: Move into the S6 Subnet**

- RDP into the S6 subnet using the S1 user's credentials.

---

### Phase 3: Privilege Escalation 

**Step 8: Acquire Local Administrator Credentials**

- Use the Task Manager GUI to dump `lsass.exe` process memory and exfil via PowerShell.
- Dump the local Administrator's password from the process dump offline using Pypykatz.

**Step 9: Get Domain Administrator Credentials via RCE**

- Use the local administator credentials to execute remote WMIC commands on the SHRPT server for RCE.
- Commands remotely dump `lsass.exe` via comsvcs.dll and extract it via PowerShell.
- Dump the Domain Administrator's password from the process dump offline using Pypykatz.

---

### Phase 4: Impact

**Step 10: Generate & Extract Active Directory Backup via RCE**

- Use the domain administrator credentials to execute remote scheduled tasks on the Domain Controller for RCE.
- Use `fodhelper.ps1` to perform a UAC bypass and create a local backup of current Active Directory instance.
- Exfiltrate the generated Active Directory backup via PowerShell.